﻿using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    /// <summary>
    /// Controls details on Recap tab Page
    /// </summary>
    public class RecapPage
    {
        private readonly BrowserSession _browserSession;
        public RecapPage(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        #region Existing clauses elements
        public IEnumerable<ElementScope> Clauses => _browserSession.FindAllCss("div.cpm-cp-clause");
        public IEnumerable<ElementScope> SpecificNorgrainClause => _browserSession.FindAllXPath("//div[@class='cpm-cp-clause cursor-pointer']//span[contains(text(),'ARBITRATION:')]");
        public IEnumerable<ElementScope> SpecificBaltimoreClause => _browserSession.FindAllXPath("//div[@class='cpm-cp-clause cursor-pointer']//span[contains(text(),'PART 1')]");
        public IEnumerable<ElementScope> ClauseLinesCurrent => _browserSession.FindAllCss("div.cpm-cp-clause-line-current");
        public IEnumerable<ElementScope> ClauseLinesAddTextCurrent => _browserSession.FindAllCss("ins.ice-ins.ice-cts-1");
        public ElementScope HighlightedClause => _browserSession.FindCss("DIV[class='cpm-cp-clause-title text-bold cursor-pointer']");
        public IEnumerable<ElementScope> AMWELSH1979Clauses => _browserSession.FindAllCss(".cpm-cp-clause-line-text");
        public IEnumerable<ElementScope> OpenFirstClause => _browserSession.FindAllCss("div > div > p > span.fa.fa-caret-right");
        #endregion Existing clauses elements

        #region Create CP Elements
        public ElementScope CopySensitiveFields => _browserSession.FindXPath("(//input[@type='radio']/../span[@class='circle'])[1]");
        public ElementScope LastDoneWarning => _browserSession.FindCss("div[ng-repeat='ld in vm.lastDoneCPPerTerms']");
        #endregion Create CP Elements

        #region Summary details
        public ElementScope CPDate => _browserSession.FindField("body > div.cpm-main-content > div > div > div > ng-form > div > div > div > span > div > div:nth-child(1) > div:nth-child(1) > cpm-cp-details-component > div > div > div:nth-child(1) > div:nth-child(2) > div > div > input");
        public ElementScope DraftStatus => _browserSession.FindXPath("//select/option[contains(text(),'Draft')]");
        public ElementScope OnSubsStatus => _browserSession.FindXPath("//select/option[contains(text(),'On Subs')]");
        public ElementScope WorkingCopyStatus => _browserSession.FindXPath("//select/option[contains(text(),'Working Copy')]");
        public ElementScope FinalStatus => _browserSession.FindXPath("//select/option[contains(text(),'Final')]");
        public ElementScope FullyFixed => _browserSession.FindXPath("//select/option[contains(text(),'Fully Fixed')]");
        public ElementScope CancelledStatus => _browserSession.FindXPath("//select/option[contains(text(),'Cancelled')]");
        public ElementScope CPReference => _browserSession.FindXPath("//div[@class='cpm-cp-header row']//li[2]/div[1]/h1");

        #endregion Summary details
        
        #region Preamble Elements
        public ElementScope PreambleHeader => _browserSession.FindXPath("//h2[contains(@scrollto,\'Preamble\')]/parent::div");
        public ElementScope PreambleMenu => _browserSession.FindXPath("//a[contains(text(),'Preamble')]");
        public ElementScope OwnerGroup => _browserSession.FindCss("INPUT[id='ownerGroup']");
        public ElementScope OwnerGroupSelect => _browserSession.FindCss("LI[ng-click='selectMatch($index, $event)']");
        public ElementScope Owner => _browserSession.FindCss("[ng-model='vm.linkedCompany.OwnerCompany.Company']");
        public ElementScope OwnerAndContact => _browserSession.FindCss("DIV[datafield-id='OwnerAndContact'] > textarea");
        public ElementScope Charterer => _browserSession.FindCss("[ng-model='vm.linkedCompany.CSCompany.Company']");
        public ElementScope ChartererAndContact => _browserSession.FindCss("DIV[datafield-id='ChartererAndContact'] > textarea");
        #endregion Preamble Elements
        
        #region Vessel Details Elements
        public ElementScope SearchQ88 => _browserSession.FindCss("#vessel-header > div > form > div > input");
        public ElementScope Q88SearchButton => _browserSession.FindCss("#vessel-header> div > form > div > span > button");
        public ElementScope Q88VesselSuggestion => _browserSession.FindXPath("//UL[@ng-show='isOpen() && !moveInProgress']/LI/A");
        public ElementScope VesselDesriptionHeader => _browserSession.FindCss(".cpm-form-group #vessel-header + div.cpm-form-group-content");
        public ElementScope PopulatedImoNumber => _browserSession.FindXPath("//textarea[@id='imo-number']");
        public ElementScope PopulatedVesselName => _browserSession.FindXPath("//textarea[@id='imo-number']//..//..//DIV[@datafield-id='VesselName']/textarea");
        public ElementScope VesselNameTextArea => _browserSession.FindCss("DIV[datafield-id='VesselName'] > textarea");
        public ElementScope AsbatVesselName => _browserSession.FindXPath("//input[@placeholder='Search Q88...']//..//..//..//..//..//input[@id='vessel']");
        public ElementScope YARACHARTERVesselName => _browserSession.FindXPath("//input[@placeholder='Search Q88...']//..//..//..//..//..//input[@id='vessel-name']");
        #endregion Vessel Details Elements

        #region Fixture MainTerms Elements
        public ElementScope FixtureMainTermsHeader => _browserSession.FindXPath("//h2[contains(@scrollto,\'Fixture\')]/parent::div");
        #endregion Fixture MainTerms Elements

        #region Header menu buttons Elements
        public ElementScope ToolbarDropDownMenu => _browserSession.FindXPath("//div[@class='cpm-toolbar-button dropdown']");
        public ElementScope FixtureRecapButton => _browserSession.FindXPath("//a[contains(text(),'Export Recap')]");
        public ElementScope RecapTab => _browserSession.FindXPath("//span[contains(text(),'Recap')]");
        public ElementScope SaveButton => _browserSession.FindXPath("//button[@class='btn cpm-button-blue save-button']");
        public ElementScope DeleteButton => _browserSession.FindCss("Button[uib-tooltip='Delete']");
        public ElementScope FixtureCharterPartyButton => _browserSession.FindXPath("//a[contains(text(),'Export Charter Party')]");
        public ElementScope UndoButton => _browserSession.FindCss("BUTTON[uib-tooltip='Undo']");
        public ElementScope RedoButton => _browserSession.FindCss("BUTTON[uib-tooltip='Redo']");
        public ElementScope DiscardChangesButton => _browserSession.FindCss("BUTTON[uib-tooltip='Discard Changes']");
        public ElementScope CreateACopyButton => _browserSession.FindCss("A[ng-click='vm.createCopy()']");
        public ElementScope AddAdditionalClauseButton => _browserSession.FindCss("BUTTON[uib-tooltip='Add Additional Clause']");
        public ElementScope CopyLinkButton => _browserSession.FindCss("BUTTON[uib-tooltip='Copy Link']");
        public ElementScope YesButton => _browserSession.FindButton("Yes");
        public ElementScope AddAdditionalClausesButton => _browserSession.FindButton("Add Additional Clauses");
        #endregion Header menu buttons Elements

        #region Addenda
        public ElementScope Addenda => _browserSession.FindXPath("//a[contains(text(),'Addenda')]");
        public ElementScope ToolBarAddAddenda => _browserSession.FindCss(".cp-detail-button.ng-scope[type='button'][uib-tooltip='Add Addendum']");
        public ElementScope AddAddenda => _browserSession.FindXPath("//h2[contains(text(),'Addenda')]/button");
        public ElementScope Name => _browserSession.FindXPath("//div[@id='addContentModalName']/following-sibling::input");
        public ElementScope Addendum => _browserSession.FindCss("#editora1");
        public ElementScope AddendaName => _browserSession.FindCss("#cpm-cp-");
        #endregion Addenda

        #region
        public ElementScope EmailNotificationButton => _browserSession.FindXPath("//a[contains(text(),'Send Notification email')]");
        public ElementScope EmailNotifiedUserName => _browserSession.FindCss("body > div.modal.fade.in > div > div > div.share-cp > div > div:nth-child(1) > div > div:nth-child(4) > div > label");
        public ElementScope CloseDialog => _browserSession.FindButton("CANCEL");
        public ElementScope DeclarationAlerts => _browserSession.FindXPath("//h2[@id='declaration-header']/a");
        public ElementScope AlertsButton => _browserSession.FindCss("#cpm-cp-declarations > button");
        public ElementScope AddVesselOption => _browserSession.FindCss("div.cpm-vessel-option-add");
        #endregion

        #region Recap Page methods
        public RecapPage ChooseAnyClauseToEdit(string templateName)
        {
            Thread.Sleep(1000);
            switch (templateName)
            {
                case "NORGRAIN74":
                    var specificNorgrainClause = SpecificNorgrainClause.WithAny();
                    specificNorgrainClause.ClickElement();
                    break;
                case "BALTIMOREBERTHCP1913":
                    var specificBaltimoreClause = SpecificBaltimoreClause.WithAny();
                    specificBaltimoreClause.ClickElement();
                    break;
                case "AMWELSH1979":
                    OpenFirstClause.First().ClickElement();
                    var specificAMWELSH1979Clause = AMWELSH1979Clauses.WithAny();
                    specificAMWELSH1979Clause.ClickElement();
                    break;
                case "YARACHARTER":
                    OpenFirstClause.First().ClickElement();
                    Thread.Sleep(500);
                    var specificYARACHARTERClause = AMWELSH1979Clauses.WithAny();
                    specificYARACHARTERClause.ClickElement();
                    break;
                case "BPVOY4CLEARLAKE":
                case "BPVOY4VITOL2006":
                case "BPVOY4VITOLTORM2007":
                    OpenFirstClause.First().ClickElement();
                    Thread.Sleep(500);
                    var specificBPVOY4Clause = AMWELSH1979Clauses.WithAny();
                    specificBPVOY4Clause.ClickElement();
                    break;
                default:
                    var anyClauses = Clauses.WithAny();
                    anyClauses.ClickElement();
                    break;
            }
            return this;
        }
        
        public RecapPage EditAnyCurrentClauseLines(string editMessage)
        {
            var anyCurrentClausesLines = ClauseLinesCurrent.ToList().Last();
            anyCurrentClausesLines.ClickElement();
            Thread.Sleep(500);
            Retry.Timeout(() =>
            {
                var clausesLines = ((IWebDriver)_browserSession.Native).FindElements(By.CssSelector("cp-content-line-directive div.cpm-cpcld-inner-container"));
                var lastLineToEdit = clausesLines.ToList().Where(x => !string.IsNullOrWhiteSpace(x.Text)).Last();
                lastLineToEdit.ClickElement();
                Thread.Sleep(TimeSpan.FromSeconds(3));
            }, 5);
            Retry.Timeout(() =>
            {
                var editClausesLines = ((IWebDriver)_browserSession.Native).FindElements(By.CssSelector("cpm-cp-ckeditor-component div"));
                var lastLine = editClausesLines.ToList().Last();
                lastLine.SendKeys(OpenQA.Selenium.Keys.Control + "a");
                lastLine.SendKeys(OpenQA.Selenium.Keys.Delete);
                lastLine.SendKeys(editMessage);
            }, 5);
            return this;
        }

        public RecapPage ClickOnRecapTab()
        {
            RecapTab.Click();
            return this;
        }

        public RecapPage EnterSummaryDetails(string cpDate)
        {
            CPDate.Enter(cpDate);
            return this;
        }

        public RecapPage EnterQ88Number(string imoNumber)
        {
            SearchQ88.Enter(imoNumber);
            new System.Threading.ManualResetEvent(false).WaitOne(1000);
            Q88SearchButton.Click();
            Thread.Sleep(1000);
            
            var elementVesselDetails = _browserSession.FindXPath("//h2[contains(text(),'Vessel')]");
            if (elementVesselDetails.Exists())
            {
                elementVesselDetails.ClickElement();
            }
            else
            {
                elementVesselDetails = _browserSession.FindXPath("//h2[contains(text(),'VESSEL DETAILS')]");
                elementVesselDetails.ClickElement();
            }
            
            return this;
        }

        public RecapPage EnterVesselName(string vesselName)
        {
            SearchQ88.Enter(vesselName);
            new System.Threading.ManualResetEvent(false).WaitOne(1000);
            return this;
        }
        public void ClickOnExportFixtureRecap()
        {
            ToolbarDropDownMenu.Click();
            FixtureRecapButton.Click();
        }

        public void ClickOnExportFixtureCharterParty()
        {
            ToolbarDropDownMenu.Click();
            FixtureCharterPartyButton.Click();
            Thread.Sleep(TimeSpan.FromSeconds(15));

        }

        public void RetryCheckFileExist(string anyParamter, string pattern)
        {
            Retry.Timeout(() => CheckFileDownloaded(anyParamter, pattern), 30);
        }

        public void CheckFileDownloaded(string anyParamter, string pattern)
        {
            if (!File.Exists(anyParamter))
            {
                Assert.Fail("File not exported yet");
            }
        }

        public RecapPage ClickOnSaveButton()
        {
            SaveButton.ClickElement();
            new System.Threading.ManualResetEvent(false).WaitOne(5000);
            return this;
        }

        public RecapPage ClickDraftStatus()
        {
            DraftStatus.Click();
            return this;
        }
        public RecapPage ClickOnSubsStatus()
        {
            OnSubsStatus.Click();
            return this;
        }
        public RecapPage ClickWorkingCopyStatus()
        {
            WorkingCopyStatus.Click();
            return this;
        }
        public RecapPage ClickFinalStatus()
        {
            FinalStatus.Click();
            return this;
        }
        public RecapPage ClickFullyFixedStatus()
        {
            FullyFixed.Click();
            return this;
        }
        public RecapPage ClickCancelledStatus()
        {
            CancelledStatus.Click();
            return this;
        }

        public string GetCPId()
        {
            string cpIdWithTemplate = CPReference.Text;
            return cpIdWithTemplate.Split(' ').Last();
        }
        public RecapPage ClickAddendaMenu()
        {
            Addenda.Click();
            return this;
        }

        public RecapPage ClickAddAddenda()
        {
            AddAddenda.ClickElement();
            return this;
        }

        public RecapPage EnterAddendumDetails(string name, string description)
        {
            Thread.Sleep(3000);
            Name.Enter(name);
            Retry.Timeout(() => Addendum.SendKeys(description), 10);
            return this;
        }

        public RecapPage ClickEmailNotificationButton()
        {
            ToolbarDropDownMenu.Click();
            EmailNotificationButton.Click();
            return this;
        }

        public RecapPage ClickCloseDialog()
        {
            CloseDialog.Click();
            return this;
        }

        public RecapPage ClickCopyLinkButton()
        {
            CopyLinkButton.Click();
            return this;
        }
        
        public RecapPage ClickUndoButton()
        {
            UndoButton.Click();
            return this;
        }

        public RecapPage ClickRedoButton()
        {
            RedoButton.Click();
            return this;
        }

        public RecapPage ClickDiscardChangesButton()
        {
            DiscardChangesButton.Click();
            return this;
        }

        public RecapPage ClickYesButton()
        {
            YesButton.Click();
            return this;
        }

        public RecapPage ClickPreambleMenu()
        {
            PreambleMenu.Click();
            return new RecapPage(_browserSession);
        }

        public RecapPage EnterOwner(string OwnerName, string TemplateName)
        {
            switch (TemplateName)
            {
                case "BOXTIMEMAERSK":
                    OwnerAndContact.Enter(OwnerName);
                    break;
                default:
                    Owner.Enter(OwnerName);
                    break;
            }
            return this;
        }
        public RecapPage EnterCharterer(string ChartererName, string TemplateName)
        {
            switch (TemplateName)
            {
                case "BOXTIMEMAERSK":
                    ChartererAndContact.Enter(ChartererName);
                    break;
                default:
                    Charterer.Enter(ChartererName);
                    break;
            }
            return this;
        }

        public RecapPage EnterVessel(string VesselName, string TemplateName)
        {
            switch (TemplateName)
            {
                case "GENCON1994":
                case "AMWELSH1979":
                case "AMWELSH1993":
                case "HYDROCHARTER2017":
                case "NORGRAIN74":
                case "NYPE46":
                case "TATASTEELGATE":
                case "BOXTIMEMAERSK":
                case "ANGLOAMERICAN":
                    VesselNameTextArea.Enter(VesselName);
                    break;
                case "ASBATANKVOY1977":
                    AsbatVesselName.Enter(VesselName);
                    break;
                case "YARACHARTER":
                    YARACHARTERVesselName.Enter(VesselName);
                    break;
                default:
                    PopulatedVesselName.Enter(VesselName);
                    break;
            }

            return this;
        }

        public DeclarationAlertsPage ClickDeclarationAlertsButton()
        {
            DeclarationAlerts.Click();
            return new DeclarationAlertsPage(_browserSession);
        }

        public DeclarationAlertsPage ClickAlertsButton()
        {
            Retry.Timeout(() =>
            {
                AlertsButton.Click();
                _browserSession.HasContent("Add Declaration Alert");
            }, 5);
            Thread.Sleep(TimeSpan.FromSeconds(5));
            return new DeclarationAlertsPage(_browserSession);
        }

        public RecapPage EnterOwnerGroup(string ownerGroup)
        {
            OwnerGroup.Enter(ownerGroup);
            return this;
        }

        public RecapPage ClickOwnerGroupSelect()
        {
            OwnerGroupSelect.Click();
            return this;
        }

        public RecapPage ClickCreateACopy()
        {
            ToolbarDropDownMenu.Click();
            while (!CreateACopyButton.Exists())
            {
                Thread.Sleep(250);
            }
            CreateACopyButton.Click();
            return this;
        }

        public RecapPage ClickCopySensitiveFields()
        {
            CopySensitiveFields.Click();
            return this;
        }

        public RecapPage ClickLastDoneWarning()
        {
            LastDoneWarning.Click();
            return this;
        }

        public RecapPage ClickAddVesselOption()
        {
            AddVesselOption.ClickElement();
            return this;
        }
        #endregion
    }
}