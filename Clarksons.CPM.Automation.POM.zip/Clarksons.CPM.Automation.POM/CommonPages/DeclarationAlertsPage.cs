﻿using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using System;
using System.Threading;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    /// <summary>
    /// Controls details on Declaration Alert Page
    /// </summary>
    public class DeclarationAlertsPage
    {
        private readonly BrowserSession _browserSession;
        public DeclarationAlertsPage(BrowserSession browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Declaration Alerts page objects 
        public ElementScope DeclarationAlertTextArea => _browserSession.FindXPath("//div[contains(@label,'Alert')]/textarea");
        public ElementScope DeclarationAlertRecipients => _browserSession.FindXPath("//label[contains(text(),'Alert Recipients')]/following-sibling::input");
        public ElementScope ScheduleDateTimeText => _browserSession.FindCss(".content-inline.cpm-cp-declaration-date>p");
        public ElementScope DeclarationAlertText => _browserSession.FindCss(".content-inline.cpm-cp-declaration-description>p");
        public ElementScope Calender => _browserSession.FindCss(".input-group-addon");
        public ElementScope CalenderArrowRight => _browserSession.FindCss(".glyphicon.glyphicon-chevron-right");
        public ElementScope ScheduleDate => _browserSession.FindXPath("//td[contains(text(),'10')]");
        public ElementScope ScheduleHour => _browserSession.FindXPath("//span[@class='hour'][contains(text(),'12:00 AM')]");
        public ElementScope ScheduleMinutes => _browserSession.FindXPath("//span[@class='minute'][contains(text(),'12:00 AM')]");
        public ElementScope TimeZone => _browserSession.FindXPath("//select[@ng-model='vm.timeZone']/option[contains(text(),'London')]");
        public ElementScope CreateButton => _browserSession.FindButton("CREATE");
        #endregion 

        #region Declaration Alerts page methods
        public DeclarationAlertsPage AddDeclarationAlert(string declationText)
        {
            Retry.Timeout(() => DeclarationAlertTextArea.Enter(declationText), 10);
            DeclarationAlertRecipients.Enter("Abc@clarksons.com; xyz@clarksons.com");
            Thread.Sleep(500);
            Calender.Click();
            Console.WriteLine("Calender.Click() successfully!");      // added for debugging.
            Thread.Sleep(500);
            CalenderArrowRight.Click();
            Console.WriteLine("CalenderArrowRight.Click() successfully!");      // added for debugging.
            Thread.Sleep(1000);
            ScheduleDate.Click();
            Console.WriteLine("ScheduleDate.Click() successfully!");      // added for debugging.
            Thread.Sleep(500);
            ScheduleHour.Click();
            Console.WriteLine("ScheduleHour.Click() successfully!");      // added for debugging.
            Thread.Sleep(500);
            ScheduleMinutes.Click();
            Console.WriteLine("ScheduleMinutes.Click() successfully!");      // added for debugging.
            Thread.Sleep(500);
            TimeZone.Click();
            Thread.Sleep(500);
            CreateButton.Click();
            return this;
        }

        public string GetScheduleDateTime()
        {
            return ScheduleDateTimeText.Text;
        }

        public string GetDeclarationAlertText()
        {
            return DeclarationAlertText.Text.ToLower();
        }
        #endregion
    }
}