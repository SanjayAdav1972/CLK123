﻿using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Interactions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    /// <summary>
    /// Controls details on Editor Page
    /// </summary>
    public class EditorPage : HelperMethod
    {
        protected BrowserSession _browserSession;
        public EditorPage(BrowserSession browserSession) : base(browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Editor page objects
        public ElementScope EditorTabButton => _browserSession.FindXPath("//span[text() = 'Charter Party']");
        public ElementScope SaveButton => _browserSession.FindId("cpm-share-button");
        public IEnumerable<ElementScope> ClauseLinesAddedText => _browserSession.FindAllXPath("//ins[@class='ice-ins ice-cts-1' and contains(text(),'Automation')]");
        public ElementScope OwnerName => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='OwnerCompany']");
        public ElementScope OwnerAndContact => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='OwnerAndContact']");
        public ElementScope ChartererName => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='CSCompany']");
        public ElementScope ChartererAndContact => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='ChartererAndContact']");
        public ElementScope VesselName => _browserSession.FindXPath("//dfplaceholder[@dfsystemname='VesselName']");

        public ElementScope AngloAmericanOwnerName => _browserSession.FindXPath("//p[contains(text(),'Parties:')]//..//..//..//..//..//..//td[2]//dfplaceholder[@dfsystemname='OwnerCompany']");
        public ElementScope AngloAmericanCharterName => _browserSession.FindXPath("//p[contains(text(),'Parties:')]//..//..//..//..//..//..//td[2]//dfplaceholder[@dfsystemname='CSCompany']");
        public ElementScope asbatankVoy1977OwnerTitle => _browserSession.FindXPath("//p[contains(text(),'IT IS THIS DAY AGREED between ')]//dfplaceholder[@dfsystemname='OwnerCompany']");
        public ElementScope asbatankVoy1977CharterName => _browserSession.FindXPath("//p[contains(text(),'and ')]//dfplaceholder[@dfsystemname='CSCompany']");
        public ElementScope asbatankVoy1977VesselName => _browserSession.FindXPath("//table[@id='preamble']//tr[5]//dfplaceholder[@dfsystemname='VesselName']");

        public ElementScope AdditionalClauseTitleAsba => _browserSession.FindCss(".additional-clauses-header #view-1");
        public ElementScope AdditionalClauseTitleBoxtime => _browserSession.FindXPath("//tr[2]//div[@class='cpm-cpcld-inner-container']/p[@id='view-1']");
        public ElementScope AdditionalClauseTitle => _browserSession.FindXPath("//cp-add-clause-title-directive//p/ins");
        public ElementScope AdditionalClauseTitleExxon => _browserSession.FindCss(".cpm-clause-title.bold-underlined");

        public IEnumerable<ElementScope> BoxtimeClauseLine => _browserSession.FindAllCss("p[text-line-order='330']");
        public IEnumerable<ElementScope> BaltimoreClauseLine => _browserSession.FindAllCss("p[text-line-order='44']");
        public IEnumerable<ElementScope> EXXONVOY84ClauseLine => _browserSession.FindAllCss("p[text-line-order='200']");
        public IEnumerable<ElementScope> ShellClauseLine => _browserSession.FindAllCss("p[text-line-order='500']");
        public IEnumerable<ElementScope> Clauses => _browserSession.FindAllCss("p[text-line-order='120']");
        #endregion

        #region Editor page methods
        public EditorPage ClickOnEditorTab()
        {
            Retry.Timeout(() => EditorTabButton.Click(), 10);
            return this;
        }

        public string VerifyAdditionalClauseTitle()
        {
            return AdditionalClauseTitle.Text.ToLower();
        }

        public string VerifyAdditionalClauseAsba()
        {
            return AdditionalClauseTitleAsba.Text.ToLower();
        }

        public string VerifyAdditionalClauseBoxtime()
        {
            return AdditionalClauseTitleBoxtime.Text.ToLower();
        }

        public string VerifyAdditionalClauseExxon()
        {
            return AdditionalClauseTitleExxon.Text.ToLower();
        }

        public string VerifyPlaceholderText()
        {
            var dataFieldPlaceholders = Retry.Timeout(() => FindElements(By.XPath("//dfplaceholder[@dfsystemname='VesselName' and @title='Vessel Name']")), 10);
            var anyCurrentClausesLines = dataFieldPlaceholders.ToList().First();
            return anyCurrentClausesLines.Text;
        }

        public void VerifyPlaceHolderWithEnteredValueExists(String p_Value)
        {
            var xPathToBeVerify = "//dfplaceholder[@dfsystemname='VesselName' and contains(text(), '"+ p_Value + "')]";
            var dataFieldPlaceholders = FindElements(By.XPath(xPathToBeVerify));
            Assert.IsTrue(dataFieldPlaceholders.ToList().First().Enabled);
        }

        public EditorPage ClickPlaceholder()
        {
            Thread.Sleep(500);
            Retry.Timeout(() =>
            {
                Actions actions1 = new Actions(((IWebDriver)_browserSession.Native));
                var dataFieldPlaceholdersLine = FindElements(By.XPath("//p/dfplaceholder[@dfsystemname='VesselName']"));
                var anyCurrentClausesLines = dataFieldPlaceholdersLine.ToList().First();

                // First click the parent to make it editable
                FindElements(By.XPath("//p/dfplaceholder[@dfsystemname='VesselName']/..")).ToList().First().Click();
                
                //anyCurrentClausesLines.Click();
                actions1.ClickAndHold(dataFieldPlaceholdersLine.ToList().First()).MoveByOffset(1, 1).Perform();
                actions1.Click(dataFieldPlaceholdersLine.ToList().First()).Perform();
            }, 5);

            Retry.Timeout(() =>
            {
                Actions actions = new Actions(((IWebDriver)_browserSession.Native));
                var dataFieldPlaceholders = FindElements(By.XPath("//div/dfplaceholder[@dfsystemname='VesselName']"));
                actions.ClickAndHold(dataFieldPlaceholders.ToList().Last()).MoveByOffset(1, 1).Perform();
                actions.DoubleClick(dataFieldPlaceholders.ToList().Last()).Perform();
            }, 5);
            return this;
        }

        public EditorPage EnterDataIntoPlaceholder(string value)
        {
            Thread.Sleep(1000);
            var inputPlaceholderPopup = FindElement(By.XPath("//div[@class='col-md-12']/div/input"));
            inputPlaceholderPopup.Clear();
            inputPlaceholderPopup.SendKeys(value);
            Thread.Sleep(750);
            SaveButton.Click();

            // Cancel the pop-up which sometimes does go away after save
            var cancelPopup = _browserSession.FindXPath("//span[@class='has-icon icon--close cursor-pointer pull-right']");
            if (cancelPopup.Exists())
            {
                cancelPopup.ClickElement();
            }

            return this;
        }

        public EditorPage EnterDataIntoPlaceholderBoxtime(string value)
        {
            var textareaPlaceholderPopup = FindElement(By.XPath("//div[@class='col-md-12']/div/textarea"));
            textareaPlaceholderPopup.Clear();
            textareaPlaceholderPopup.SendKeys(value);
            SaveButton.Click();
            return this;
        }

        protected string GetElementValue(IWebElement elem)
        {
            string actualValue = null;
            switch (elem.TagName.ToLower())
            {
                case "textarea":
                    actualValue = GetTextAreaValue(elem);
                    break;
                case "input":
                    actualValue = GetInputValue(elem);
                    break;
                default:
                    actualValue = elem.GetAttribute("value") ?? elem.Text;
                    break;
            }
            return actualValue;
        }

        private string GetInputValue(IWebElement elem)
        {
            elem = FindElement(By.XPath("//input[@class='cke_dialog_ui_input_text']"));
            string elem1 = elem.GetAttribute("value") ?? elem.Text;
            return elem1;
        }

        private string GetTextAreaValue(IWebElement elem)
        {
            elem = FindElement(By.XPath("//textarea[@class='cke_dialog_ui_input_textarea']"));
            string elem2 = elem.GetAttribute("value") ?? elem.Text;
            return elem2;

        }

        public void ClauseName(string name, string editText)
        {
            var clauseElement = FindElement(By.XPath(String.Format("//p[contains(text(),'{0}')]", name.ToUpper())));
            clauseElement.Click();
            clauseElement.Clear();
            clauseElement.SendKeys(editText);
        }

        public EditorPage EditAnyCurrentClauseLines(string p_TemplateName, string editMessage)
        {
            //Thread.Sleep(2000);
            var cssSelector = ".cpm-cpcld-hover-container cpm-cp-ckeditor-component div";
            var editClausesLine = FindElement(By.CssSelector(cssSelector));
            while (!editClausesLine.Enabled)
            {
                Thread.Sleep(250);
            }
            editClausesLine.SendKeys(editMessage);
            Thread.Sleep(TimeSpan.FromSeconds(5));
            return this;
        }

        public IList<string> GetAddedText()
        {
            var addedTextElements = _browserSession.FindAllCss("ins.ice-ins.ice-cts-1").ToList();
            var addedTexts = new List<string>();
            addedTextElements.ForEach(e => addedTexts.Add(e.Text.Trim()));
            return addedTexts;
        }

        public EditorPage ChooseAnyClauseToEdit(string templateName)
        {
            Thread.Sleep(3000);
            switch (templateName)
            {
                case "BOXTIMEMAERSK":
                case "BOXTIME":
                    Thread.Sleep(5000);
                    var boxtimeClauses = BoxtimeClauseLine.WithAny();
                    boxtimeClauses.ClickElement();
                    break;
                case "BALTIMOREBERTHCP1913":
                    var baltimoreClauses = BaltimoreClauseLine.WithAny();
                    baltimoreClauses.ClickElement();
                    Thread.Sleep(500);
                    break;
                case "AMWELSH1979":
                    Thread.Sleep(5000);     // Added extra wait for this template only
                    var specificAMWELSH1979Clause = BaltimoreClauseLine.WithAny();
                    specificAMWELSH1979Clause.ClickElement();
                    break;
                case "EXXONVOY84":
                case "EXXONVOY84SCANPORT":
                    var specificEXXONVOY84Clause = EXXONVOY84ClauseLine.WithAny();
                    specificEXXONVOY84Clause.ClickElement();
                    break;
                case "SHELLTIME4":
                    var specificShellClause = ShellClauseLine.WithAny();
                    specificShellClause.ClickElement();
                    break;
                default:
                    var anyClauses = Clauses.WithAny();
                    anyClauses.ClickElement();
                    break;
            }
            Thread.Sleep(500);
            return this;
        }

        public string VerifyOwnerName(string TemplateName)
        {
            switch (TemplateName)
            {
                case "BOXTIMEMAERSK":
                    return OwnerAndContact.Text;
                case "ANGLOAMERICAN":
                    return AngloAmericanOwnerName.Text;
                case "ASBATANKVOY1977":
                    return asbatankVoy1977OwnerTitle.Text;
                default:
                    return OwnerName.Text;
            }
        }

        public void VerifyOwnerNameOnTemplate(string p_owner, string p_TemplateName)
        {
            var xPathToBeVerify = "";
            switch (p_TemplateName)
            {
                case "BOXTIMEMAERSK":
                    xPathToBeVerify = "//dfplaceholder[@dfsystemname='OwnerAndContact' and contains(text(),'" + p_owner + "')]";
                    break;
                case "ANGLOAMERICAN":
                    xPathToBeVerify = "//p[contains(text(),'Parties:')]//..//..//..//..//..//..//td[2]//dfplaceholder[@dfsystemname='OwnerCompany' and contains(text(),'" + p_owner + "')]";
                    break;
                case "ASBATANKVOY1977":
                    xPathToBeVerify = "//p[contains(text(),'IT IS THIS DAY AGREED between ')]//dfplaceholder[@dfsystemname='OwnerCompany' and contains(text(),'" + p_owner + "')]";
                    break;
                default:
                    xPathToBeVerify = "//dfplaceholder[@dfsystemname='OwnerCompany' and contains(text(),'" + p_owner + "')]";
                    break;
            }

            var dataFieldPlaceholders = FindElements(OpenQA.Selenium.By.XPath(xPathToBeVerify));
            Assert.IsTrue(dataFieldPlaceholders.ToList().First().Enabled);
        }

        public string VerifyChartererName(string TemplateName)
        {
            switch (TemplateName)
            {
                case "BOXTIMEMAERSK":
                    return ChartererAndContact.Text;
                case "ANGLOAMERICAN":
                    return AngloAmericanCharterName.Text;
                case "ASBATANKVOY1977":
                    return asbatankVoy1977CharterName.Text;
                default:
                    return ChartererName.Text;
            }
        }

        public void VerifyChartererNameOnTemplate(string p_owner, string p_TemplateName)
        {
            var xPathToBeVerify = "";
            switch (p_TemplateName)
            {
                case "BOXTIMEMAERSK":
                    xPathToBeVerify = "//dfplaceholder[@dfsystemname='ChartererAndContact' and contains(text(),'" + p_owner + "')]";
                    break;
                case "ANGLOAMERICAN":
                    xPathToBeVerify = "//p[contains(text(),'Parties:')]//..//..//..//..//..//..//td[2]//dfplaceholder[@dfsystemname='CSCompany' and contains(text(),'" + p_owner + "')]";
                    break;
                case "ASBATANKVOY1977":
                    xPathToBeVerify = "//p[contains(text(),'and ')]//dfplaceholder[@dfsystemname='CSCompany' and contains(text(),'" + p_owner + "')]";
                    break;
                default:
                    xPathToBeVerify = "//dfplaceholder[@dfsystemname='CSCompany' and contains(text(),'" + p_owner + "')]";
                    break;
            }

            var dataFieldPlaceholders = FindElements(OpenQA.Selenium.By.XPath(xPathToBeVerify));
            Assert.IsTrue(dataFieldPlaceholders.ToList().First().Enabled);
        }

        public string VerifyVesselName(string p_TemplateName)
        {
            switch (p_TemplateName)
            {
                case "ASBATANKVOY1977":
                    return asbatankVoy1977VesselName.Text;
                default:
                    return VesselName.Text;
            }
        }

        public void VerifyVesselNameOnTemplate(string p_owner, string p_TemplateName)
        {
            var xPathToBeVerify = "";
            switch (p_TemplateName)
            {
                case "ASBATANKVOY1977":
                    xPathToBeVerify = "//table[@id='preamble']//tr[5]//dfplaceholder[@dfsystemname='VesselName' and contains(text(),'" + p_owner + "')]";
                    break;
                default:
                    xPathToBeVerify = "//dfplaceholder[@dfsystemname='VesselName' and contains(text(),'" + p_owner + "')]";
                    break;
            }

            var dataFieldPlaceholders = FindElements(OpenQA.Selenium.By.XPath(xPathToBeVerify));
            Assert.IsTrue(dataFieldPlaceholders.ToList().First().Enabled);
        }
        #endregion
    }
}