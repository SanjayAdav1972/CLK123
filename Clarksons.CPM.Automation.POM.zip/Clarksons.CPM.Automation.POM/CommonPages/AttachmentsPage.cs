﻿using Clarksons.CPM.Automation.Utilities;
using Coypu;
using System;
using System.IO;
using System.Windows.Forms;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    /// <summary>
    /// Controls details on Attachments Page
    /// </summary>
    public class AttachmentsPage
    {
        private readonly BrowserSession _browserSession;
        public AttachmentsPage(BrowserSession browserSession)
        {
            this._browserSession = browserSession;
        }

        #region Editor page objects
        public ElementScope BrowseButton => _browserSession.FindCss(".cpm-flow-attachment-content div button");
        public ElementScope CreateButton => _browserSession.FindXPath("//div[@class='modal-footer']//button[contains(text(),'CREATE')]");
        public ElementScope ExistingAttachments => _browserSession.FindCss(".cpm-cp-attachment-wrapper");
        public ElementScope AttachmentTab => _browserSession.FindXPath("//span[contains(text(),'Attachments')]");
        public ElementScope AttachmentDownload => _browserSession.FindCss("DIV[ng-click='vm.downloadAttachment(attachment.AttachmentId)']");
        public ElementScope AttachmentDelete => _browserSession.FindCss("DIV[ng-click='vm.removeAttachment(attachment.AttachmentId)']");
        public ElementScope NoAttachmentsFound => _browserSession.FindXPath("//span[contains(text(), 'No Attachment(s) found.')]");
        #endregion

        #region Editor page methods
        public AttachmentsPage AddAttachment(string FileName, string attachmentFileName)
        {
            var filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, FileName);
            //$@"DataFiles\CPM\SampleAttachment.xlsx");
            BrowseButton.Click();
            System.Threading.Thread.Sleep(3000);
            SendKeys.SendWait(filePath);
            SendKeys.SendWait(@"{Enter}");
            System.Threading.Thread.Sleep(3000);
            //DescriptionText.SendKeys(attachmentFileName);
            //CreateButton.Click();
            return this;
        }

        public string GetAttachedDocumentText()
        {
            return Retry.Timeout(() => { return ExistingAttachments.Text.ToLower(); }, 3);
        }

        public void ClickOnAttachments()
        {
            AttachmentTab.Click();
        }

        public void ClickOnAttachmentDownload()
        {
            AttachmentDownload.Click();
        }

        public void ClickOnAttachmentDelete()
        {
            AttachmentDelete.Click();
        }
        #endregion
    }
}