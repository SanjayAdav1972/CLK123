﻿using Clarksons.CPM.Automation.Utilities.Extensions;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using System.Threading;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    /// <summary>
    /// Controls details on Invoicing Page
    /// </summary>
    public class InvoicingPage
    {
        private readonly BrowserSession _browserSession;
        public InvoicingPage(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        #region Invoicing Page objects
        public ElementScope CPIDField => _browserSession.FindXPath("//div[@class='form-group has-feedback']/label[contains(text(),'CP ID:')]/following-sibling::input");
        public ElementScope CompanyField => _browserSession.FindCss("div[class='form-group has-feedback']>input[ng-model='vm.company']");
        public ElementScope CompanyFieldDropdown => _browserSession.FindCss("ul[class='dropdown-menu']");
        public ElementScope CompanyExpandButton => _browserSession.FindXPath("//div/cpm-invoicing-to-be-invoiced-component//table/tbody/tr/td[2]/div/i");
        public ElementScope ID => _browserSession.FindXPath("//table//tbody//tr[@ng-repeat='id in aid.CPs']/td/a[@class='cpm-invoicing-download-link']");
        public ElementScope ActionCheckBox => _browserSession.FindXPath("//table//tbody//tr[@ng-repeat='id in aid.CPs']/td/div/input[@type='checkbox']");
        public ElementScope RaiseButton => _browserSession.FindButton("Raise");
        public ElementScope ConfirmButton => _browserSession.FindButton("CONFIRM");
        public ElementScope InvoicePageBillingDateTo => _browserSession.FindXPath("//label[contains(text(),'Billing Date To:')]//../p/input");
        #endregion

        #region Invoicing page methods
        public InvoicingPage EnterCPID(string cpId)
        {
            CPIDField.Enter(cpId);
            Thread.Sleep(5000);
            return this;
        }

        public InvoicingPage ClickActionOnCP(string cpId)
        {
            Thread.Sleep(5000);
            CompanyExpandButton.Click();
            Thread.Sleep(1000);

            if (!ActionCheckBox.Exists())
            {
                CompanyExpandButton.Click();
            }

            Thread.Sleep(5000);
            string id = ID.Text;
            if (cpId == id)
            {
                ActionCheckBox.ClickElement();
                Thread.Sleep(1000);
            }
            else
            {
                var failMessage = string.Format("CPID {0} is not displayed", id);
                var helper = new HelperMethod(_browserSession);
                helper.CreateSoftAssertion(failMessage);
            }

            return this;
        }

        public InvoicingPage ClickCompanyFieldDropdown()
        {
            CompanyFieldDropdown.ClickElement();
            return this;
        }

        public InvoicingPage RaiseInvoice()
        {
            RaiseButton.Click();
            ConfirmButton.Click();
            return this;
        }
        #endregion
    }
}