﻿using Coypu;
using OpenQA.Selenium;

namespace Clarksons.CPM.Automation.POM.CommonPages
{
    /// <summary>
    /// Controls details on Navigation Menu
    /// </summary>
    public class NavigationMenu
    {
        private readonly BrowserSession _browserSession;
        public NavigationMenu(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }

        #region Sidebar menu page objects
        public ElementScope InvoicingMenu => _browserSession.FindXPath("//li[@class='cpm-sidebar-item']//span[contains(text(),'Invoicing')]");
        public ElementScope HomeLink => _browserSession.FindXPath("//div[@class='logo']");
        #endregion

        #region Sidebar menu methods
        public InvoicingPage ClickInvoicingMenu()
        {
            InvoicingMenu.Click();
            return new InvoicingPage(_browserSession);
        }

        public NavigationMenu ClickHomeLink()
        {
            HomeLink.Click();
            return this;
        }

        public NavigationMenu AcceptAlert()
        {
            var webDriver = ((IWebDriver)_browserSession.Native);
            webDriver.SwitchTo().Alert().Accept();
            return this;
        }

        public NavigationMenu NavigateBack()
        {
            var webDriver = ((IWebDriver)_browserSession.Native);
            webDriver.Navigate().Back();
            return this;
        }
        #endregion
    }
}