﻿using Coypu;

namespace Clarksons.CPM.Automation.POM.CPM
{
    /// <summary>
    /// Controls details on Charter Party Search Page
    /// </summary>
    public class CharterPartySearchPage
    {
        private readonly BrowserSession _browserSession;
       
        public CharterPartySearchPage(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }
    }
}