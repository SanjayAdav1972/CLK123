﻿using Coypu;

namespace Clarksons.CPM.Automation.POM.CPM
{
    /// <summary>
    /// Controls details on CPM Search Page
    /// </summary>
    public class CpmSearch
    {
        private readonly BrowserSession _browserSession;
        public CpmSearch(BrowserSession browserSession)
        {
            _browserSession = browserSession;
        }
    }
}