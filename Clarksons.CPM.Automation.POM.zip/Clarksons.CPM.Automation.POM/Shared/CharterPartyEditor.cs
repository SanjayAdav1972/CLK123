﻿using Coypu;
using System.Collections.Generic;

namespace Clarksons.CPM.Automation.POM.Shared
{
    /// <summary>
    /// Controls details on Charter Party Editor Page
    /// </summary>
    public class CharterPartyEditor : BasePageObject
    {
        public CharterPartyEditor(BrowserSession browserSession) : base(browserSession) { }
        public IEnumerable<ElementScope> Lines => AllCss("div.cptec-ckeditor-content > div p");
    }
}