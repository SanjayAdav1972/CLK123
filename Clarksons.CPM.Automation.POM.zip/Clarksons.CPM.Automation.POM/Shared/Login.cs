﻿using Coypu;

namespace Clarksons.CPM.Automation.POM.Shared
{
    /// <summary>
    /// Controls details on Login Page
    /// </summary>
    public class Login : BasePageObject
    {
        public Login(BrowserSession browserSession) : base(browserSession) { }

        public ElementScope Username => Field("Username");
        public ElementScope Password => Field("Password");
        public ElementScope ProceedButton => Button("Login");
        public ElementScope ReleaseNotesDialogClose => Button("Close");
    }
}