﻿using BoDi;
using NUnit.Framework;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public class Q88ImportSteps : BaseSteps
    {
        public Q88ImportSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [Then(@"I verify correct '(.*)' and '(.*)' for template '(.*)' displayed")]
        [Then(@"I verify that Q88 populates correct Imonumber '(.*)' and '(.*)' for template '(.*)'")]
        public void ThenIVerifyThatQPopulatesCorrectImonumberAndForTemplate(string p_Imo, string p_Vesselname, string p_TemplateName)
        {
            switch (p_TemplateName)
            {
                case "AMWELSH1979":
                    page.WaitUntilLoaded();
                    Assert.AreEqual(p_Imo, recapPage.PopulatedImoNumber.Value);
                    Assert.AreEqual(p_Vesselname, recapPage.VesselNameTextArea.Value);
                    break;
                case "YARACHARTER":
                    page.WaitUntilLoaded();
                    Assert.AreEqual(p_Imo, recapPage.PopulatedImoNumber.Value);
                    Assert.AreEqual(p_Vesselname, recapPage.PopulatedVesselName.Value);
                    break;
                default:
                    helperMethod.CreateSoftAssertion("UNKNOW FORM TEMPLATE");
                    break;
            }
        }

        [When(@"I search for Vessel details with Vessel Name '(.*)'")]
        public void WhenISearchForVesselDetailsWithVesselName(string vesselName)
        {
            recapPage.EnterVesselName(vesselName);
        }

        [Then(@"I verify that Q88 suggests the correct vessel '(.*)'")]
        public void ThenIVerifyThatQSuggestsTheCorrectVessel(string suggestedVessel)
        {
            Assert.AreEqual(suggestedVessel, recapPage.Q88VesselSuggestion.Text);
        }
    }
}