﻿using BoDi;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public sealed class DeclarationAlertsSteps : BaseSteps
    {
        public DeclarationAlertsSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [StepDefinition(@"I add Declaration alerts as '(.*)'")]
        public void WhenIAddDeclarationAlerts(string declationText)
        {
            declarationAlertsPage.AddDeclarationAlert(declationText);
        }

        [StepDefinition(@"I click on add Declaration alerts for Recap Manager '(.*)'")]
        [StepDefinition(@"I click on add Declaration alerts for Charter Party Manager '(.*)'")]
        public void ThenIClickOnAddDeclarationAlertsForCharterPartyManager(string p_ChartererName)
        {
            switch (p_ChartererName)
            {
                case "RM":
                    recapPage.ClickDeclarationAlertsButton();
                    break;
                case "CPM":
                    recapPage.ClickAlertsButton();
                    break;
                default:
                    helperMethod.CreateSoftAssertion("UNKNOW CHARTERER");
                    break;
            }
        }
    }
}