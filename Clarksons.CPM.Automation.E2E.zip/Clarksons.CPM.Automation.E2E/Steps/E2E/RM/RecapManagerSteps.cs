﻿using BoDi;
using Clarksons.CPM.Automation.E2E.Data.Fields;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Config;
using Clarksons.CPM.Automation.Utilities.Data;
using Clarksons.CPM.Automation.Utilities.Helper;
using Coypu;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public class RecapManagerSteps : BaseSteps
    {
        private IEnumerable<string> preambleInputs;
        private IEnumerable<string> vesselInputs;
        private IEnumerable<string> fixtureInputs;
        protected BrowserSession _browserSession;
        string filePath = Setting.UserDownloadPath;
        public string pageUrlOriginal { get; set; }

        public RecapManagerSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [When(@"I land on Charter Party manager template '(.*)'")]
        [When(@"I land on Recap manager template '(.*)'")]
        public void ILandOnRecapManagerTemplate(string p_TemplateName)
        {
            var pageUrl = helperMethod.GetPageUrl().ToLower();

            string templateName;
            switch (p_TemplateName)
            {
                case "BPVOY4":
                    templateName = "bpvoy4".ToLower();
                    break;
                case "BPVOY5":
                    templateName = "bpvoy5".ToLower();
                    break;
                case "BPVOY4CLEARLAKE":
                    templateName = "bpvoy4clearlake".ToLower();
                    break;
                case "BPVOY4STVOY2006":
                    templateName = "BPVOY4STVOY2006".ToLower();
                    break;
                case "BPVOY4STVOY2010":
                    templateName = "BPVOY4STVOY2010".ToLower();
                    break;
                case "BPVOY4VITOL2006":
                    templateName = "BPVOY4VITOL2006".ToLower();
                    break;
                case "BPVOY4VITOL2010":
                    templateName = "BPVOY4VITOL2010".ToLower();
                    break;
                case "BPVOY4VITOLTORM2007":
                    templateName = "BPVOY4VITOLTORM2007".ToLower();
                    break;
                case "BPVOY4VITOLMANSEL":
                    templateName = "BPVOY4VITOLMANSEL".ToLower();
                    break;
                case "EXXONMOBILVOY2005":
                    templateName = "EXXONMOBILVOY2005".ToLower();
                    break;
                case "EXXONMOBILVOY2005SOCAR":
                    templateName = "EXXONMOBILVOY2005".ToLower();
                    break;
                case "EXXONMOBILVOY2005VALERO":
                    templateName = "EXXONMOBILVOY2005VALERO".ToLower();
                    break;
                case "OMVOY2001":
                    templateName = "OMVOY2001".ToLower();
                    break;
                case "SHELLVOY6-V1-1-APR06":
                    templateName = "SHELLVOY6-V1-1-APR06 ".ToLower();
                    break;
                case "SHELLTIME4":
                    templateName = "SHELLTIME4 ".ToLower();
                    break;
                case "EXXONVOY84SCANPORT":
                    templateName = "EXXONVOY84SCANPORT".ToLower();
                    break;
                case "EXXONMOBILVOY2005TESORO":
                    templateName = "EXXONMOBILVOY2005TESORO".ToLower();
                    break;
                case "EXXONVOY84":
                    templateName = "EXXONVOY84".ToLower();
                    break;
                case "AMWELSH1979":
                    templateName = "AMWELSH1979".ToLower();
                    break;
                case "ASBATANKVOY1977":
                    templateName = "ASBATANKVOY1977".ToLower();
                    break;
                case "BOXTIMEMAERSK":
                    templateName = "BOXTIMEMAERSK".ToLower();
                    break;
                case "NYPE46":
                    templateName = "NYPE46".ToLower();
                    break;
                case "GENCON1994":
                    templateName = "GENCON1994".ToLower();
                    break;
                case "YARACHARTER":
                    templateName = "YARACHARTER".ToLower();
                    break;
                case "AMWELSH1993":
                    templateName = "AMWELSH1993".ToLower();
                    break;
                case "ANGLOAMERICAN":
                    templateName = "ANGLOAMERICAN".ToLower();
                    break;
                case "NORGRAIN74":
                    templateName = "NORGRAIN74".ToLower(); ;
                    break;
                case "HYDROCHARTER2017":
                    templateName = "HYDROCHARTER2017".ToLower();
                    break;
                case "TATASTEELGATE":
                    templateName = "TATASTEELGATE".ToLower();
                    break;
                case "RTMVOY1Q15":
                    templateName = "RTMVOY1Q15".ToLower();
                    break;
                case "BALTIMOREBERTHCP1913":
                    templateName = "BALTIMOREBERTHCP1913".ToLower();
                    break;
                case "GENCON76":
                    templateName = "GENCON76".ToLower();
                    break;
                case "ROYHILL":
                    templateName = "ROYHILL".ToLower();
                    break;
                case "NORGRAIN89":
                    templateName = "NORGRAIN89".ToLower();
                    break;
                case "VALEVOY2014":
                    templateName = "VALEVOY2014".ToLower();
                    break;
                case "BHPBVOY2014":
                    templateName = "BHPBVOY2014".ToLower();
                    break;
                case "NYPE93":
                    templateName = "NYPE93".ToLower();
                    break;
                case "ARCELORMITTALIRONORECP2014":
                    templateName = "ARCELORMITTALIRONORECP2014".ToLower();
                    break;
                case "EUROMED1997":
                    templateName = "EUROMED1997".ToLower();
                    break;
                case "FIXTURENOTE":
                    templateName = "FIXTURENOTE".ToLower();
                    break;
                case "FMGVOY2012":
                    templateName = "FMGVOY2012".ToLower();
                    break;
                case "NYPE81":
                    templateName = "NYPE81".ToLower();
                    break;
                default:
                    templateName = "UNKNOWN";
                    break;
            }

            if (!pageUrl.Contains(templateName))
                helperMethod.CreateSoftAssertion(string.Format("Recap manager template {0} not handled", p_TemplateName));
        }

        [When(@"I enter values into all blank fields with CP Date")]
        public void WhenIEnterValuesIntoAllBlankFieldsWithCPDate()
        {

            var preambleHeader = recapPage.PreambleHeader;
            var vesselDescriptionHeader = recapPage.VesselDesriptionHeader;
            var fixtureMainTermsHeader = recapPage.FixtureMainTermsHeader;
            //Enter Preamble empty fields
            this.preambleInputs = preambleHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1,
                excludeInputs: new string[] { "RegisteredOwner", "CommercialOperator", "OwnerGroup" });
            //Enter Vessel empty fields
            this.vesselInputs = vesselDescriptionHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });
            //Enter Fixture empty fields
            this.fixtureInputs = fixtureMainTermsHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1,
                excludeInputs: new string[] { "e-part-cargo-minimum", "j-day-rate" });

            var cpDate = DateTime.Now.AddDays(2).ToString("dd-MM-yyyy");
            charterParty.SpecifyCPDate(cpDate);
        }

        [StepDefinition(@"I see specific clauses '(.*)' displayed on editor tab for templates '(.*)'")]
        public void ISeeSpecificClausesDisplayedOnEditorTabForTemplates(string p_SpecificClauses, string p_TemplateName)
        {
            switch (p_TemplateName)
            {
                case "BPVOY4":
                    if (!existingClausesPage.BPVOY4Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY5":
                    if (!existingClausesPage.BPVOY5Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4CLEARLAKE":
                    if (!existingClausesPage.BPVOY4CLEARLAKEClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4STVOY2006":
                    if (!existingClausesPage.BPVOY4STVOY2006Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4STVOY2010":
                    if (!existingClausesPage.BPVOY4STVOY2010Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOL2006":
                    if (!existingClausesPage.BPVOY4VITOL2006Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOL2010":
                    if (!existingClausesPage.BPVOY4VITOL2010Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOLTORM2007":
                    if (!existingClausesPage.BPVOY4VITOLTORM2007Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BPVOY4VITOLMANSEL":
                    if (!existingClausesPage.BPVOY4VITOLMANSELClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005":
                    if (!existingClausesPage.EXXONMOBILVOY2005Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005SOCAR2010":
                    if (!existingClausesPage.EXXONMOBILVOY2005SOCAR2010Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005VALERO":
                    if (!existingClausesPage.EXXONMOBILVOY2005VALEROClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "OMVOY2001":
                    if (!existingClausesPage.OMVOY2001Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "SHELLVOY6-V1-1-APR06":
                    if (!existingClausesPage.SHELLVOY6Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "SHELLTIME4":
                    if (!existingClausesPage.SHELLTIME4Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONVOY84SCANPORT":
                    if (!existingClausesPage.EXXONVOY84SCANPORTClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONMOBILVOY2005TESORO":
                    if (!existingClausesPage.EXXONMOBILVOY2005TESOROClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EXXONVOY84":
                    if (!existingClausesPage.EXXONVOY84Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ASBATANKVOY1977":
                    if (!existingClausesPage.ASBAClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BOXTIMEMAERSK":
                    if (!existingClausesPage.BOXTIMEMAERSKClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BOXTIME":
                    if (!existingClausesPage.BOXTIMEClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "GENCON1994":
                    if (!existingClausesPage.Gencon94Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "YARACHARTER":
                    if (!existingClausesPage.YaraCharterClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "AMWELSH1993":
                    if (!existingClausesPage.AMWELSH93Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ANGLOAMERICAN":
                    if (!existingClausesPage.ANGLOAMERICANClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NORGRAIN74":
                    if (!existingClausesPage.NORGRAIN74Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NORGRAIN89":
                    if (!existingClausesPage.NORGRAIN89Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "HYDROCHARTER2017":
                    if (!existingClausesPage.HYDROCHARTER2017Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "TATASTEELGATE":
                    if (!existingClausesPage.TATASTEELGATEClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "RTMVOY1Q15":
                    if (!existingClausesPage.RTMVOY1Q15Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BALTIMOREBERTHCP1913":
                    if (!existingClausesPage.BALTIMOREClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "GENCON76":
                    if (!existingClausesPage.GENCON76Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ROYHILL":
                    if (!existingClausesPage.ROYHILLClauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "VALEVOY2014":
                    if (!existingClausesPage.VALEVOY2014Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "BHPBVOY2014":
                    if (!existingClausesPage.BHPBVOY2014Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NYPE93":
                    if (!existingClausesPage.NYPE93Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "ARCELORMITTALIRONORECP2014":
                    if (!existingClausesPage.ARCELORMITTALIRONORECP2014Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "EUROMED1997":
                    if (!existingClausesPage.EUROMED1997Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "FMGVOY2012":
                    if (!existingClausesPage.FMGVOY2012Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                case "NYPE81":
                    if (!existingClausesPage.NYPE81Clauses(p_SpecificClauses))
                        helperMethod.CreateSoftAssertion(String.Format("Fail to verify clauses on {0}", p_TemplateName));
                    break;
                default:
                    helperMethod.CreateSoftAssertion("UNKNOW FORM TEMPLATE");
                    break;
            }

            System.Threading.Thread.Sleep(5000);
        }

        [StepDefinition(@"I click on export Fixture Charter Party")]
        public void IClickOnExportFixtureCharterParty()
        {
            recapPage.ClickOnExportFixtureCharterParty();
        }

        [Then(@"I see my file has been downloaded successfully")]
        public void ISeeMyFileHasBeenDownloadedSuccessfully()
        {
            int timeOutPeriod = 90;
            if (ScenarioContext.Current["TemplateName"].ToString() == "RTMVOY1Q15" || ScenarioContext.Current["TemplateName"].ToString() == "VALEVOY2014" || ScenarioContext.Current["TemplateName"].ToString() == "ANGLOAMERICAN")
            {
                timeOutPeriod = 300;
            }

            bool fileDownloaded = false;
            Retry.Timeout(() => fileDownloaded = FileHelper.CheckFileExist("Export*.pdf", $"-{page.GetCPId()}-"), timeOutPeriod);
            Console.WriteLine("download status {0}", fileDownloaded);
        }

        [StepDefinition(@"I click on export Fixture Recap")]
        public void IClickOnExportFixtureRecap()
        {
            recapPage.ClickOnExportFixtureRecap();
        }

        [StepDefinition(@"I click on the downloaded file to open it")]
        public void IClickOnTheDownloadedFileToOpenIt()
        {
            Thread.Sleep(3000);
            Retry.Timeout(() =>
            {
                var cpid = page.GetCPId();
                FileInfo file = FileHelper.GetFile(filePath, "Export*.pdf", $"-{cpid}-");
                string fileContents = PDFParser.PdfText(file.FullName);
                fileContents = fileContents.Replace("\n", " ").Replace("\u00A0", " ");
                scenarioContext.Add("FileContent", fileContents.ToLower());
            }, 60);
        }

        [Then(@"I can see expected file with '(.*)' contents")]
        public void ICanSeeExpectedFileWithContents(string p_EditedMessage)
        {
            var fileContents = scenarioContext.Get<string>("FileContent");
            Assert.IsTrue(fileContents.Contains(p_EditedMessage.ToLower()));
        }

        [Then(@"I can see expected file without '(.*)' contents")]
        public void ThenICanSeeExpectedFileWithoutContents(string p_EditedMessage)
        {
            var fileContents = scenarioContext.Get<string>("FileContent");
            Assert.IsFalse(fileContents.Contains(p_EditedMessage.ToLower()));
        }

        [When(@"I edit existing clauses '(.*)' to verify text been edited on Recap tab for template '(.*)'")]
        public void WhenIEditExistingClausesToVerifyTextBeenEditedOnRecapTabForTemplate(string p_EditMessage, string p_TemplateName)
        {
            Thread.Sleep(1000);
            recapPage.ChooseAnyClauseToEdit(p_TemplateName);
            Thread.Sleep(1000);
            page.WaitUntilLoaded();
            recapPage.EditAnyCurrentClauseLines(p_EditMessage);
            Thread.Sleep(1000);
            var editedClauseTextList = recapPage.ClauseLinesAddTextCurrent.ToList();
            var editedClauseText = editedClauseTextList.First().Text.ToLower();
            scenarioContext.Add("EditedClause", editedClauseText);
            Assert.IsTrue(editedClauseText.Contains(p_EditMessage.ToLower()), string.Format("edited clause message {0} but was {1}", p_EditMessage.ToLower(), editedClauseText));
        }

        [StepDefinition(@"I see ameded existing clause message'(.*)' displayed on Editor tab")]
        public void ISeeAmededExistingClauseMessageDisplayedOnEditorTab(string p_RecapEditMessage)
        {
            var editedClause = scenarioContext.Get<string>("EditedClause");
            var editedClasueTextList = editorPage.ClauseLinesAddedText.ToList();
            var editedClauseText = editedClasueTextList.First().Text.ToLower();
            Assert.IsTrue(editedClauseText.Contains(p_RecapEditMessage.ToLower()), string.Format("edited clause message is {0} but was {1}", p_RecapEditMessage.ToLower(), editedClauseText));
        }

        [When(@"I edit details '(.*)' under editor tab to verify if editable for template '(.*)'")]
        public void WhenIEditDetailsUnderEditorTabToVerifyIfEditableForTemplate(string p_EditorEditMessage, string p_TemplateName)
        {
            editorPage.ChooseAnyClauseToEdit(p_TemplateName);
            var extraSpaceToHelpWithWordWrapOnJoinedWords = " ";
            editorPage.EditAnyCurrentClauseLines(p_TemplateName, p_EditorEditMessage
                + extraSpaceToHelpWithWordWrapOnJoinedWords);
        }

        [When(@"I see amended '(.*)' details displayed on Editor tab")]
        public void WhenISeeAmendedDetailsDisplayedOnEditorTab(string p_EditorEditMessage)
        {
            var addedTextList = editorPage.GetAddedText();
            foreach (string editText in addedTextList)
            {
                if (editText.ToLower().Contains(p_EditorEditMessage.ToLower()))
                {
                    StringAssert.AreEqualIgnoringCase(p_EditorEditMessage, editText);
                    break;
                }
            }
        }

        [Then(@"I can see expected file with declaration text added correctly as '(.*)'")]
        public void ThenICanSeeExpectedFileWithDeclarationScheduleTimeContents(string declationText)
        {
            var fileContents = scenarioContext.Get<string>("FileContent");
            var declarationText = declarationAlertsPage.GetDeclarationAlertText();
            Assert.IsTrue(fileContents.Contains(declationText.ToLower()));
        }

        [When(@"I remember URL")]
        public void WhenIRememberURL()
        {
            pageUrlOriginal = helperMethod.GetPageUrl();
        }

        [When(@"I click create a copy and enter Broker Company and Charterer Company")]
        public void WhenIClickCreateACopyAndEnter()
        {
            recapPage.ClickCreateACopy();
            charterParty.SpecifyBroker(Setting.Company.Broker);
            charterParty.SpecifyCharterer(Setting.Company.Charterer);
        }

        [When(@"I copy sensitive fields")]
        public void WhenICopySensitiveFields()
        {
            recapPage.ClickCopySensitiveFields();
            charterParty.CreateNew();
        }

        [Then(@"I should see last done warning")]
        public void ThenIShouldSeeLastDoneWarning()
        {
            Assert.AreEqual(recapPage.LastDoneWarning.Text.Trim(), "Click here to view last done without terms");
        }

        [Then(@"I should navigate to last done CP")]
        public void ThenIShouldNavigateToLastDoneCP()
        {
            recapPage.ClickLastDoneWarning();
            string pageUrl = helperMethod.GetPageUrl();
            Assert.AreEqual(pageUrlOriginal, pageUrl);
        }

        [When(@"I populate the Owner Group with '(.*)'")]
        public void WhenIPopulateTheOwnerGroupWith(string ownerGroup)
        {
            recapPage.EnterOwnerGroup(ownerGroup);
            recapPage.ClickOwnerGroupSelect();
        }
    }
}