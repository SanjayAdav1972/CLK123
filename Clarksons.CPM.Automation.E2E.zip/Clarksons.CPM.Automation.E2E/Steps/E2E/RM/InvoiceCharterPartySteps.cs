﻿using BoDi;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Database;
using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Threading;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public class CharterPartyBPVOYSteps : BaseSteps
    {
        public CharterPartyBPVOYSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [StepDefinition(@"I change status to '(.*)'")]
        public void ThenIChangeStatusFromDraftToFullyFixed(string status)
        {
            var click = new Dictionary<string, Func<object>>()
            {
                { "draft", recapPage.ClickDraftStatus },
                { "on subs", recapPage.ClickOnSubsStatus },
                { "working copy", recapPage.ClickWorkingCopyStatus },
                { "fully fixed", recapPage.ClickFullyFixedStatus },
                { "final", recapPage.ClickFinalStatus },
                { "cancelled", recapPage.ClickCancelledStatus }
            };

            click[status.ToLower()]();
        }

        [Then(@"I update Fully fixed date to past in DB")]
        public void ThenIUpdateFullyFixedDateToPastInDB()
        {
            var cpId = recapPage.GetCPId();
            var queryToUpdateDate = string.Format("update cpm.cp set cp.FullyFixedDate = DATEADD(day,-31, GETDATE()) where CPId = '{0}'", cpId);
            new DbInteraction().ExecuteUpdateQuery(queryToUpdateDate);
            scenarioContext.Add("CPID", cpId);
        }

        [StepDefinition(@"I query Alerts in DB table")]
        public void WhenIQueryAlertsInDBTable()
        {
            var cpId = recapPage.GetCPId();
            var queryToExecute = string.Format("select count(*) count from CPM.Email where AssociatedEntityId='{0}' and emailchangetype=3 ", cpId);
            //new DbInteraction().ExecuteSelectQuery(queryToExecute);
            var noOfAlerts = new DbInteraction().ExecuteSelectQueryAndReturnData(queryToExecute).GetValue(0);
            scenarioContext.Add("CPID", cpId);
            scenarioContext.Add("AlertsCount", noOfAlerts);
        }

        [Then(@"I navigate to Addenda menu")]
        public void ThenINavigateToAddendaMenu()
        {
            page.Refresh();
            Thread.Sleep(3000);
            recapPage.ClickAddendaMenu();
        }

        [Then(@"I click on add new Addenda")]
        public void ThenIClickOnAddNewAddenda()
        {
            Thread.Sleep(1000);
            recapPage.ClickAddAddenda();
        }

        [Then(@"I add New Addendum with Name '(.*)' with description '(.*)'")]
        public void ThenIAddNewAddendumWithNameWithDescription(string p_Name, string p_Description)
        {
            recapPage.EnterAddendumDetails(p_Name, p_Description);
            charterParty.CreateNew();
        }

        [Then(@"I see new addendum '(.*)'added under Addenda section on recap tab")]
        public void ThenISeeNewAddendumAddedUnderAddendaSectionOnRecapTab(string p_AddendaName)
        {
            var newAddendaName = recapPage.AddendaName.Text.ToLower();
            Assert.IsTrue(newAddendaName.Contains(p_AddendaName.ToLower()), "new Addenda name is {0} but was {1}", p_AddendaName, newAddendaName);
        }

        [Then(@"I Navigate to Invoicing page")]
        public void ThenINavigateToInvoicingPage()
        {
            // Store CPAId in ScenarioContext before going to Invoicing page.
            var cpId = recapPage.GetCPId();
            scenarioContext.Add("CPID", cpId);

            Thread.Sleep(TimeSpan.FromSeconds(5));
            Retry.Timeout(() => search.ClickAdministrationMenu(), 5);     // Invoicing in under Administration menu now.
            navigationMenu.ClickInvoicingMenu();
        }

        [Then(@"I search for fully fixed Charter party with CPID")]
        public void ThenISearchForFullyFixedCharterPartyWithCPID()
        {
            var cpId = scenarioContext.Get<string>("CPID");
            invoicingPage.EnterCPID(cpId);
            Thread.Sleep(1000);
        }

        [Then(@"I search for fully fixed Charter party with '(.*)'")]
        public void ThenISearchForFullyFixedCharterPartyWith(string company)
        {
            while (!invoicingPage.CompanyField.Exists())
            {
                Thread.Sleep(250);
            }

            invoicingPage.CompanyField.FillInWith(company);
            invoicingPage.ClickCompanyFieldDropdown();
        }

        [Then(@"I search for fully fixed Charter party with broker company")]
        public void ThenISearchForFullyFixedCharterPartyWithBrokerCompany()
        {
            // Billing Date To - end date of the Current month
            var dt = DateTime.Now.AddDays(10).ToString("dd/MM/yyyy");
            invoicingPage.InvoicePageBillingDateTo.FillInWith(dt);

            var brokerCompany = scenarioContext.Get<string>("BrokerCompany");
            while (!invoicingPage.CompanyField.Exists())
            {
                Thread.Sleep(250);
            }

            invoicingPage.CompanyField.FillInWith(brokerCompany);
            Thread.Sleep(2000);
        }

        [Then(@"I click on Action of that Charter Party")]
        public void ThenIClickOnActionOfThatCharterParty()
        {
            var cpId = scenarioContext.Get<string>("CPID");
            invoicingPage.ClickActionOnCP(cpId);
        }

        [Then(@"I raise invoice for that Charter Party")]
        public void ThenIRaiseInvoiceForThatCharterParty()
        {
            invoicingPage.RaiseInvoice();
        }
    }
}