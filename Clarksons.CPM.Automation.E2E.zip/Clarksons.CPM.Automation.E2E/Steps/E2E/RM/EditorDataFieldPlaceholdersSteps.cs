﻿using BoDi;
using Clarksons.CPM.Automation.Utilities;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.RM
{
    [Binding]
    public sealed class EditorDataFieldPlaceholdersSteps : BaseSteps
    {
        public EditorDataFieldPlaceholdersSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [Then(@"I enter data into placeholder with Value '(.*)' for each template '(.*)'")]
        public void ThenIEnterDataIntoPlaceholderWithValueForEachTemplate(string p_Value, string p_TemplateName)
        {
         System.Threading.Thread.Sleep(500);

            switch (p_TemplateName)
            {
                case "BOXTIMEMAERSK":
                case "BOXTIME":
                case "GENCON1994":
                case "AMWELSH1993":
                case "HYDROCHARTER2017":
                case "NORGRAIN74":
                case "TATASTEELGATE":
                case "ANGLOAMERICAN":
                case "EXXONMOBILVOY2005":
                case "EXXONMOBILVOY2005SOCAR2010":
                case "EXXONMOBILVOY2005VALERO":
                case "EXXONVOY84SCANPORT":
                case "EXXONMOBILVOY2005TESORO":
                case "EXXONVOY84":
                case "RTMVOY1Q15":
                case "BALTIMOREBERTHCP1913":
                case "GENCON76":
                case "NORGRAIN89":
                case "ROYHILL":
                case "BHPBVOY2014":
                case "NYPE93":
                case "ARCELORMITTALIRONORECP2014":
                case "EUROMED1997":
                case "FIXTURENOTE":
                case "FMGVOY2012":
                case "NYPE81":
                    editorPage.ClickPlaceholder();
                    Retry.Timeout(() => editorPage.EnterDataIntoPlaceholderBoxtime(p_Value), 20);
                    break;
                case "NYPE46":
                case "YARACHARTER":
                case "AMWELSH1979":
                case "ASBATANKVOY1977":
                case "BPVOY4CLEARLAKE":
                case "BPVOY4":
                case "BPVOY5":
                case "BPVOY4STVOY2006":
                case "BPVOY4STVOY2010":
                case "BPVOY4VITOL2006":
                case "BPVOY4VITOL2010":
                case "BPVOY4VITOLTORM2007":
                case "BPVOY4VITOLMANSEL":
                case "OMVOY2001":
                case "SHELLVOY6-V1-1-APR06":
                case "SHELLTIME4":
                case "VALEVOY2014":
                    editorPage.ClickPlaceholder();
                    Retry.Timeout(() => editorPage.EnterDataIntoPlaceholder(p_Value), 20);
                    break;
                default:
                    helperMethod.CreateSoftAssertion("UNKNOW FORM TEMPLATE");
                    break;
            }
        }

        [Then(@"I can see entered data '(.*)' is displayed on editor tab")]
        public void ThenICanSeeEnteredDataIsDisplayedOnEditorTab(string p_Value)
        {
            editorPage.VerifyPlaceHolderWithEnteredValueExists(p_Value);
        }
    }
}