﻿using BoDi;
using Clarksons.CPM.Automation.E2E.Data.Fields;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Config;
using Clarksons.CPM.Automation.Utilities.Data;
using Clarksons.CPM.Automation.Utilities.Helper;
using NUnit.Framework;
using Should.Fluent;
using System;
using System.Collections.Generic;
using System.Threading;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.E2E.CPM
{
    [Binding]
    public sealed class CharterPartySteps : BaseSteps
    {
        private IEnumerable<string> preambleInputs;
        private IEnumerable<string> vesselInputs;
        private IEnumerable<string> fixtureInputs;
        private IEnumerable<string> detailsInput;
        private IEnumerable<string> contactDetailsInput;

        public CharterPartySteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [StepDefinition(@"I click on create a new Recap")]
        [StepDefinition(@"I click on create a new Charter Party")]
        public void WhenIClickOnCreateANewCharterParty()
        {
            charterParty.AddNewCharterParty();
        }

        [StepDefinition(@"I enter '(.*)' and '(.*)' to create template '(.*)'")]
        public void GivenIEnterAndToCreateTemplate(string broker, string charterer, string p_Template)
        {
            charterParty.SpecifyBroker(broker);
            charterParty.SpecifyCharterer(charterer);
            charterParty.SelectCharterPartyStyle(p_Template);
            charterParty.CreateNew();
        }
        
        [StepDefinition(@"I enter Broker Company and Charterer Company to create template '(.*)'")]
        public void WhenIEnterAndToCreateTemplate(string p_Template)
        {
            ScenarioContext.Current["TemplateName"] = p_Template;
            ScenarioContext.Current["BrokerCompany"] = Setting.Company.Broker;
            Thread.Sleep(500);
            charterParty.SpecifyBroker(Setting.Company.Broker);
            charterParty.SpecifyCharterer(Setting.Company.Charterer);
            charterParty.SelectCharterPartyStyle(p_Template);
            charterParty.CreateNew();
            Thread.Sleep(1000);
        }

        [StepDefinition(@"I click on Save button")]
        public void ThenIClickOnSaveButton()
        {
            recapPage.ClickOnSaveButton();
            while (recapPage.SaveButton.Disabled)
            {
                Thread.Sleep(500);
            }
        }

        [StepDefinition(@"I should see toast message '(.*)'")]
        public void ThenIShouldSeeToastMessage(string p_ToastMessage)
        {
            CodeHelper.CanFail(() =>
            {
                if (!string.IsNullOrWhiteSpace(p_ToastMessage))
                    helperMethod.VerifyThatToastMessageSays(p_ToastMessage);
            });
        }

        [StepDefinition(@"I verify the status as '(.*)'")]
        public void WhenIVerifyTheStatusAsDraft(string status)
        {
            Retry.Timeout(() => Assert.AreEqual(summaryPage.CpmStatus.SelectedOption.ToString(), status), 10);
        }
               
        [StepDefinition(@"I enter contact details under summary tab")]
        public void ThenIEnterContactDetailsUnderSummaryTab()
        {
            charterParty.WaitUntilLoaded();
            var cpDate = DateTime.Now.AddDays(2).ToString("dd-MM-yyyy");
            charterParty.SpecifyCPDate(cpDate);

            var details = summaryPage.DetailsHeader;
            var contactDetails = summaryPage.ContactDetailsHeader;
            //Enter Details empty fields
            this.detailsInput = details.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1,
                excludeInputs: new string[] { });
            //Enter contact details empty fields
            this.contactDetailsInput = contactDetails.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });
        }

        [StepDefinition(@"I verify Audit History with events as '(.*)'")]
        public void WhenIVerifyAuditHistoryWithEventsAs(string eventDescription)
        {
            switch (eventDescription)
            {
                case "Prepare CP":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditPrepareCP.Text, eventDescription), 10);
                    break;
                case "Draft To Final":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditDraft2Final.Text, eventDescription), 10);
                    break;
                case "Final To Draft":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditFinal2Draft.Text, eventDescription), 10);
                    break;
                case "Draft To Working Copy":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditDraft2WorkingCopy.Text, eventDescription), 10);
                    break;
                case "Working Copy To Draft":
                    Retry.Timeout(() => Assert.AreEqual(summaryPage.AuditWorkingCopy2Draft.Text, eventDescription), 10);
                    break;
                default:
                    Console.WriteLine("No aUDIT hISTORY appear. /nSomething wrong while writing Audit History.");
                    break;
            }
        }

        [StepDefinition(@"I navigate to Attachments tab")]
        public void ThenINavigateToAttachmentsTab()
        {
            attachmentsPage.ClickOnAttachments();
        }

        [StepDefinition(@"I navigate to History tab")]
        public void WhenINavigateToHistoryTab()
        {
            historyPage.ClickOnHistory();
        }

        [StepDefinition(@"I am able to attach documents")]
        public void ThenIAmAbleToAttachDocuments()
        {
            string FileName = $@"Data\CPM\SampleAttachment.xlsx";
            string attachmentFileName = "I successfully attached document";
            attachmentsPage.AddAttachment(FileName, attachmentFileName);
            //attachmentsPage.DescriptionText.SendKeys(attachmentFileName);
            Thread.Sleep(TimeSpan.FromSeconds(5));
            
            if (attachmentsPage.CreateButton.Exists())
            {
                attachmentsPage.CreateButton.Click();
                scenarioContext.Add("AttachmentSupport", "Yes");
                Thread.Sleep(TimeSpan.FromSeconds(5));
            }
            else
            {
                // Attachment windows form do not get displayed in TeamCity. 
                // So could add atatchment in TeamCity but working fine on desktop.
                Console.WriteLine("Attachment windows form do not get displayed in TeamCity.");
                scenarioContext.Add("AttachmentSupport", "No");
            }
        }

        [StepDefinition(@"I download my attachment")]
        public void ThenIDownloadMyAttachment()
        {
            if (scenarioContext.Get<string>("AttachmentSupport") == "Yes")
            {
                attachmentsPage.ClickOnAttachmentDownload();
                while (!attachmentsPage.AttachmentDownload.Exists())
                {
                    Thread.Sleep(500);
                }
            }
        }

        [StepDefinition(@"I delete my attachment")]
        public void ThenIDeleteMyAttachment()
        {
            if (scenarioContext.Get<string>("AttachmentSupport") == "Yes")
            {
                attachmentsPage.ClickOnAttachmentDelete();
            }
        }

        [StepDefinition(@"I see that my attchment has been deleted")]
        public void ThenISeeThatMyAttchmentHasBeenDeleted()
        {
                if (scenarioContext.Get<string>("AttachmentSupport") == "Yes")
                {
                    Assert.AreEqual(attachmentsPage.NoAttachmentsFound.Text, "No Attachment(s) found.");
                } 
        }

        [StepDefinition(@"I see my attachment has been downloaded successfully")]
        public void ThenISeeMyAttachmentHasBeenDownloadedSuccessfully()
        {
            if (scenarioContext.Get<string>("AttachmentSupport") == "Yes")
            {
                Retry.Timeout(() => Assert.IsTrue(FileHelper.CheckFileExist("Sample*.xlsx")), 60);
            }  
        }

        [StepDefinition(@"I navigate to Recap tab")]
        public void ThenINavigateToRecapTab()
        {
            Retry.Timeout(() => recapPage.ClickOnRecapTab(), 20);
        }

        [StepDefinition(@"I search for Vessel details with ImoNumber '(.*)'")]
        public void WhenISearchForVesselDetailsWithImoNumber(string p_ImoNumber)
        {
            recapPage.EnterQ88Number(p_ImoNumber);
        }

        [When(@"I enter values into all blank fields on Recap tab")]
        public void WhenIEnterValuesIntoAllBlankFieldsOnRecapTab()
        {
            var preambleHeader = recapPage.PreambleHeader;
            var vesselDescriptionHeader = recapPage.VesselDesriptionHeader;
            var fixtureMainTermsHeader = recapPage.FixtureMainTermsHeader;

            //Enter Preamble empty fields
            this.preambleInputs = preambleHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1,
                excludeInputs: new string[] { "RegisteredOwner", "CommercialOperator", "OwnerGroup" });
            //Enter Vessel empty fields
            this.vesselInputs = vesselDescriptionHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });
            //Enter Fixture empty fields
            this.fixtureInputs = fixtureMainTermsHeader.PopulateFields(
                (label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData: false, testDataSetNumber: 1, excludeInputs: new string[] { });
        }

        [When(@"I create new Additional clauses '(.*)' on Recap tab")]
        public void WhenICreateNewAdditionalClausesOnRecapTab(string p_NewAdditionalClause)
        {
            additionalClausesPage.ClickAddAdditionalClause()
                                 .DialogIsPresent()
                                 .EnterNameOfClause(p_NewAdditionalClause)
                                 .EnterClauseDetails();
        }

        [Then(@"I see new Additional clause '(.*)' added on recap tab")]
        public void ThenISeeNewAdditionalClauseAddedOnRecapTab(string p_NewAdditionalClause)
        {
            Thread.Sleep(5000);
            var actualNewAdditionalClauseText = Retry.Timeout(() => additionalClausesPage.AdditionalClauseTitle.Text.ToLower(), 20);
            Assert.IsTrue(
                actualNewAdditionalClauseText.Contains(p_NewAdditionalClause.ToLower()),
                "Additional clause title {0} but was {1}", p_NewAdditionalClause, actualNewAdditionalClauseText);
        }

        [StepDefinition(@"I navigate to Editor tab")]
        public void WhenINavigateToEditorTab()
        {
            editorPage.ClickOnEditorTab();
            page.WaitUntilLoaded();
            Thread.Sleep(10000);
        }

        [Then(@"I see added new Additional Clause '(.*)' displayed on Editor tab for template '(.*)'")]
        public void ThenISeeAddedNewAdditionalClauseDisplayedOnEditorTabForTemplate(string p_AdditionalClause, string p_Template)
        {
            switch (p_Template)
            {
                case "BPVOY4":
                case "BPVOY4CLEARLAKE":
                case "BPVOY4STVOY2006":
                case "BPVOY4STVOY2010":
                case "BPVOY4VITOL2006":
                case "BPVOY4VITOL2010":
                case "BPVOY4VITOLTORM2007":
                case "BPVOY4VITOLMANSEL":
                case "EXXONMOBILVOY2005":
                case "EXXONMOBILVOY2005SOCAR2010":
                case "EXXONMOBILVOY2005VALERO":
                case "EXXONVOY84SCANPORT":
                case "EXXONMOBILVOY2005TESORO":
                case "EXXONVOY84":
                case "OMVOY2001":
                case "SHELLVOY6-V1-1-APR06":
                case "SHELLTIME4":
                    var additionalClauseTitleBPVOY4Varients = editorPage.VerifyAdditionalClauseTitle();
                    Assert.IsTrue(additionalClauseTitleBPVOY4Varients.Contains(p_AdditionalClause.ToLower()), "Additional clause title {0} but was {1}", p_AdditionalClause, additionalClauseTitleBPVOY4Varients);
                    break;
                case "BPVOY5":
                    var actualAdditionalClauseTextBPVOY5 = bpvoy5editorPage.VerifyAdditionalClauseOnBPVOY5();
                    Assert.IsTrue(actualAdditionalClauseTextBPVOY5.Contains(p_AdditionalClause.ToLower()), "Additional clause title {0} but was {1}", p_AdditionalClause, actualAdditionalClauseTextBPVOY5);
                    break;
                case "BOXTIMEMAERSK":
                case "BOXTIME":
                case "NYPE46":
                case "GENCON1994":
                case "YARACHARTER":
                case "ANGLOAMERICAN":
                case "AMWELSH1979":
                case "AMWELSH1993":
                case "ASBATANKVOY1977":
                case "NORGRAIN74":
                case "NORGRAIN89":
                case "HYDROCHARTER2017":
                case "TATASTEELGATE":
                case "RTMVOY1Q15":
                case "BALTIMOREBERTHCP1913":
                case "GENCON76":
                case "ROYHILL":
                case "VALEVOY2014":
                case "BHPBVOY2014":
                case "NYPE93":
                case "ARCELORMITTALIRONORECP2014":
                case "EUROMED1997":
                case "FIXTURENOTE":
                case "FMGVOY2012":
                case "NYPE81":
                    var actualAdditionalClauseTextBoxtime = editorPage.VerifyAdditionalClauseBoxtime();
                    Assert.IsTrue(actualAdditionalClauseTextBoxtime.Contains(p_AdditionalClause.ToLower()), "Additional clause title {0} but was {1}", p_AdditionalClause, actualAdditionalClauseTextBoxtime);
                    break;
                default:
                    helperMethod.CreateSoftAssertion("UNKNOW FORM TEMPLATE");
                    break;
            }
        }

        [StepDefinition(@"I enter Owner '(.*)' for template '(.*)'")]
        public void WhenIEnterOwnerForTemplate(string p_Owner, string p_TemplateName)
        {
            recapPage.EnterOwner(p_Owner, p_TemplateName);
        }

        [StepDefinition(@"I enter Charterer'(.*)' for template '(.*)'")]
        public void GivenIEnterChartererForTemplate(string p_charterer, string p_TemplateName)
        {
            recapPage.EnterCharterer(p_charterer, p_TemplateName);
        }

        [StepDefinition(@"I enter Vessel '(.*)' for template '(.*)'")]
        public void WhenIEnterVesselForTemplate(string p_VesselName, string p_TemplateName)
        {
            recapPage.EnterVessel(p_VesselName, p_TemplateName);
        }

        [StepDefinition(@"I verify Owner '(.*)' for template '(.*)' on the editor tab")]
        public void WhenIVerifyOwnerOnTheEditorTab(string p_owner, string p_TemplateName)
        {
            editorPage.VerifyOwnerNameOnTemplate(p_owner, p_TemplateName);
        }

        [StepDefinition(@"I verify Charterer '(.*)' for template '(.*)' on the editor tab")]
        public void WhenIVerifyChartererOnTheEditorTab(string p_charterer, string p_TemplateName)
        {
            editorPage.VerifyChartererNameOnTemplate(p_charterer, p_TemplateName);
        }

        [StepDefinition(@"I verify VesselName '(.*)' for template '(.*)' on the editor tab")]
        public void WhenIVerifyVesselNameOnTheEditorTab(string p_VesselName, string p_TemplateName)
        {
            editorPage.VerifyVesselNameOnTemplate(p_VesselName, p_TemplateName);
        }

        [Then(@"I delete the document")]
        [Then(@"I delete the Charter Party")]
        [Then(@"I delete the Recap")]
        public void ThenIDeleteTheDocument()
        {
            charterParty.Delete();
        }

        [Then(@"I try to attach a large file")]
        public void ThenITryToAttachALargeFile()
        {
            string FileName = $@"DataFiles\CPM\20mb.test";
            string attachmentFileName = "I successfully attached document";
            attachmentsPage.AddAttachment(FileName, attachmentFileName);
        }

        [When(@"I click on Add Vessel option to add vessel details three")]
        [When(@"I click on Add Vessel option to add vessel details two")]
        public void WhenIClickOnAddVesselOptionToAddVesselDetails()
        {
            recapPage.ClickAddVesselOption();
        }

        [When(@"I wait (.*) seconds")]
        public void WhenIWaitSeconds(string p0)
        {
            Thread.Sleep(30000);
        }

        [When(@"I click the Home Button")]
        public void WhenIClickTheHomeButton()
        {
            navigationMenu.ClickHomeLink();
        }

        [When(@"I accept navigate away dialog")]
        public void WhenIAcceptNavigateAwayDialog()
        {
            navigationMenu.AcceptAlert();
        }

        [When(@"I navigate back to the CP")]
        public void WhenINavigateBackToTheCP()
        {
            navigationMenu.NavigateBack();
        }

        [When(@"I resume changes")]
        public void WhenIResumeChanges()
        {
            charterParty.ResumeEditing();
        }

        [StepDefinition(@"I will be navigated to the correct highlighted line")]
        public void ThenIWillBeNavigatedToTheCorrectHighlightedLine()
        {
            Assert.IsTrue(recapPage.HighlightedClause.Exists().Should().Be.True());
        }

        [StepDefinition(@"I search for line '(.*)' using the goToLine box")]
        public void WhenISearchForLineUsingTheGoToLineBox(string p_LineNumber)
        {
            charterParty.SpecifyGoToLine(p_LineNumber);
        }
    }
}