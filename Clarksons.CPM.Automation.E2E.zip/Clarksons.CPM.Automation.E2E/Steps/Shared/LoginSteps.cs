﻿using BoDi;
using Clarksons.CPM.Automation.Utilities.Config;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.Shared
{
    [Binding]
    public class LoginSteps : BaseSteps
    {
        public LoginSteps(IObjectContainer objectContainer) : base(objectContainer) { }

        [Given(@"Login Page")]
        public void GivenCPMLoginPage()
        {
            loginActions.Navigate();
            loginActions.AtLoginPage();
        }

        [When(@"I enter username")]
        public void WhenIEnterUsername()
        {
            var username = Setting.Login.Broker.Username;
            loginActions.EnterUsername(username);
        }

        [When(@"I enter password")]
        public void WhenIEnterPassword()
        {
            var password = Setting.Login.Broker.Password;
            loginActions.EnterPassword(password);
        }

        [When(@"Click login button")]
        public void ClickLoginButton()
        {
            loginActions.ProceedWithLogin();
        }

        [Then(@"Search Page is loaded")]
        public void ThenSearchPageIsLoaded()
        {
            search.AtSearchPage();
        }

        [When(@"I enter invalid username")]
        public void WhenIEnterInvalidUsername()
        {
            loginActions.EnterUsername("notregistered@clarksons.com");
        }

        [Then(@"Login Failure is shown")]
        public void ThenLoginFailureIsShown()
        {
            loginActions.LoginShouldHaveFailed();
        }
        
        [Given(@"I am logged on")]
        public void GivenIAmLoggedOnCPM()
        {
            search.AtSearchPage();
        }
        
        [When(@"I Sign out")]
        public void WhenISignOut()
        {
            searchActs.Logout();
        }
        
        [Then(@"Login Page is loaded ok")]
        public void ThenCPMLoginPageIsLoadedOk()
        {
            loginActions.AtLoginPage();
        }

        [Given(@"I login as a new broker")]
        public void GivenILoginAsANewBroker()
        {
            loginActs.LoginAsANewBroker();
        }

        [Given(@"I login as broker")]
        public void GivenILoginAsABroker()
        {
            loginActs.LoginAsBroker();
        }
    }
}