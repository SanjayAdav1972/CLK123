﻿using BoDi;
using TechTalk.SpecFlow;

namespace Clarksons.CPM.Automation.E2E.Steps.Shared
{
    [Binding]
    public class SharedSteps : BaseSteps
    {
        public SharedSteps(IObjectContainer objectContainer) : base(objectContainer) { }
    }
}