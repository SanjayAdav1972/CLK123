﻿using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu;
using Clarksons.CPM.Automation.Utilities.Config;

namespace Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs
{
    public class LoginActs
    {
        private readonly LoginActions loginActions;
        private readonly PageActions pageActions;

        public LoginActs(LoginActions loginActions, PageActions pageActions)
        {
            this.loginActions = loginActions;
            this.pageActions = pageActions;
        }

        public void LoginAsANewBroker()
        {
            var username = Setting.Login.NewBroker.Username;
            var password = Setting.Login.NewBroker.Password;
            LoginUsingCredentials(username, password);
        }

        public void LoginAsBroker()
        {
            var username = Setting.Login.Broker.Username;
            var password = Setting.Login.Broker.Password;
            LoginUsingCredentials(username, password);
        }

        private void LoginUsingCredentials(string username, string password)
        {
            loginActions.Navigate();
            loginActions.EnterUsername(username);
            loginActions.EnterPassword(password);
            loginActions.ProceedWithLogin();
            pageActions.ReturnToHomePage();
        }
    }
}