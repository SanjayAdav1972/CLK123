﻿using Clarksons.CPM.Automation.E2E.Runner.UI.Coypu;

namespace Clarksons.CPM.Automation.E2E.Steps.Actions.CompositActs
{
    public class SearchActs : BaseActs
    {
        private SearchActions search;
        public SearchActs(SearchActions search)
        {
            this.search = search;
        }

        public void FilterOnlyByStatus(string status)
        {
            search.UnselectAllStatusFilters();
            search.SelectStatusFilter(status);
        }

        public void Logout()
        {
            search.ClickShowMenu();
            search.LogoutIgnoreSaveChanges();
        }

        public void RemoveSearchDefaults()
        {
            search.SetChartererAs("");
            search.SetCPFormAs("");
            search.SetCreatedByAs("");
            search.SetDateMaxAs("");
            search.SetDateMinAs("");
            search.SetNamedUserAs("");
            search.SetOwnerAs("");
            search.SetVesselNameAs("");
            search.UnselectAllStatusFilters();
            if (IsAppRecapManager)
            {
                search.SelectStatusFilter("Draft");
                search.SelectStatusFilter("On Subs");
            }
            if (IsAppCharterPartyManager)
            {
                search.SelectStatusFilter("Draft");
                search.SelectStatusFilter("Working Copy");
            }
            search.SaveSearchDefaults();
        }

        public void SearchForRecap(string document)
        {
            search.SelectSearchOption(document);
        }
    }
}