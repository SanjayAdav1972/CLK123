﻿using System.Collections.Generic;
using System.Linq;

namespace Clarksons.CPM.Automation.E2E.Data.Fields
{
    /// <summary>
    /// Field Data related stuff
    /// </summary>
    public static class FieldData
    {
        private static Dictionary<string, string> FieldValidInputType = new Dictionary<string, string>()
        {
            { "IMO Number", "number" },
            { "LOA", "number" },
            { "Cubic capacity for cargo (at 98%)","number" },
            { "Crude Oil Wash System Hours", "number" },
            { "GRT", "number" },
            { "NRT", "number" }
        };

        public static string GetFieldValidInputTypeOrDefault(string fieldName, string defaultInputType)
        {
            var key = FieldValidInputType.Keys
                .OrderBy(x => x.Length)
                .FirstOrDefault(x => fieldName.Contains(x));

            if (string.IsNullOrWhiteSpace(key))
            {
                return defaultInputType;
            }

            return FieldValidInputType[key];
        }
    }
}