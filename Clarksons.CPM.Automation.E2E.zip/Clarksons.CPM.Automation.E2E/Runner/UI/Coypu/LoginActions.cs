﻿using Clarksons.CPM.Automation.POM.Shared;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using Should.Fluent;
using System;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public class LoginActions : BaseActions
    {
        public Login login { get; }
        public LoginActions(BrowserSession browserSession) : base(browserSession)
        {
            this.login = new Login(browserSession);
        }

        public void Navigate()
        {
            driver.Visit("/");
        }

        public void AtLoginPage()
        {
            driver.HasContent("LOGIN").Should().Be.True();
        }

        public void EnterPassword(string password)
        {
            login.Password.Enter(password);
        }

        public void IgnoreReleaseNotesPopup()
        {
            if (driver.HasContent("What's New", new Options() { Timeout = TimeSpan.FromMilliseconds(1000) }))
            {
                login.ReleaseNotesDialogClose.Click();
            }
        }

        public void EnterUsername(string username)
        {
            login.Username.Enter(username);
        }

        public void ProceedWithLogin()
        {
            login.ProceedButton.ClickElement();
        }

        public void ShouldHaveAuthenticated()
        {
            driver.HasNoContent("Login to Charter Party Manager").Should().Be.True();
        }

        public void LoginShouldHaveFailed()
        {
            driver.HasContent("Login Failed");
        }
    }
}