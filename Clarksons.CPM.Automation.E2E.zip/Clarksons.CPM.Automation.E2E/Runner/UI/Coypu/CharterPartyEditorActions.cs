﻿using Clarksons.CPM.Automation.POM.Shared;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using Should.Fluent;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public class CharterPartyEditorActions : BaseActions
    {
        public CharterPartyEditor editor { get; }
        private readonly BrowserSession browserSession;

        public CharterPartyEditorActions(BrowserSession browserSession) : base(browserSession)
        {
            this.editor = new CharterPartyEditor(browserSession);
            this.browserSession = browserSession;
        }

        public object ChooseAnyLineToEdit()
        {
            var lines = editor.Lines;
            return lines.WithAny();
        }

        public void ContentsShouldNotChangeForLine(object lineToEdit)
        {
            ((ElementScope)lineToEdit).CanChangeContent().Should().Be.False();
        }
    }
}