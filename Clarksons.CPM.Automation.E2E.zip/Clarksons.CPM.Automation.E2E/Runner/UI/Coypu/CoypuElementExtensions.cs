﻿using Clarksons.CPM.Automation.Utilities.Config;
using Coypu;
using OpenQA.Selenium;
using OpenQA.Selenium.Internal;
using System;

/// <summary>
/// Currently this class is not referenced anywhere in the automation
/// </summary>
namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public static class CoypuElementExtensions
    {
        private static bool UseFastInput = Setting.UseFastDataEntry;

        public static IWebElement Native(this ElementScope element)
        {
            return (IWebElement)element.Native;
        }

        private static IWebDriver NativeDriver(this ElementScope element)
        {
            return ((IWrapsDriver)element.Native()).WrappedDriver;
        }

        public static void MoveTo(this ElementScope element)
        {
            var executor = (IJavaScriptExecutor)element.NativeDriver();
            executor.ExecuteScript("arguments[0].scrollIntoView(true); window.scrollBy(0,-400);", element.Native());
        }

        public static void SelectOption(this ElementScope element, string option)
        {
            element.Click();
            element.Select(option);
        }

        public static void CanFail(Action action)
        {
            try
            {
                action();
            }
            catch
            {
            }
        }

        public static void ClickElement(this ElementScope element)
        {
            element.MoveTo();
            element.Click();
        }
    }
}