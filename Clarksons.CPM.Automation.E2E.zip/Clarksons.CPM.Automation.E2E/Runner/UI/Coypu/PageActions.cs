﻿using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using OpenQA.Selenium;
using System;
using System.Linq;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public class PageActions : BaseActions
    {
        public PageActions(BrowserSession browserSession) : base(browserSession) { }

        public void HoverOverLine(object lineToEdit)
        {
            ((ElementScope)lineToEdit).Hover();
        }

        public void IconShouldBeDefaultPointerIcon()
        {
            throw new NotImplementedException();
        }

        public void IgnoreAlert()
        {
            ((IWebDriver)driver.Native).AlertIgnore();
        }

        public void Refresh()
        {
            WaitUntilLoaded();
            driver.Refresh();
            WaitUntilLoaded();
        }

        public void RefreshAndLoseChanges()
        {
            WaitUntilLoaded();
            driver.Refresh();
            ((IWebDriver)driver.Native).AlertAccept();
        }

        public void ReturnToHomePage()
        {
            WaitUntilLoaded();
            driver.Visit("/");
            WaitUntilLoaded();
            driver.HasNoContent("No Results");
            WaitUntilLoaded();
        }

        public void Url(string url)
        {
            driver.Visit(url);
        }

        public string GetCPId()
        {
            var slugs = driver.Location.AbsoluteUri.Split('/');
            var numbers = slugs
                .Where(x => int.TryParse(x, out int o))
                .Where(x => int.Parse(x) > 1);
            return numbers.Last();
        }
    }
}