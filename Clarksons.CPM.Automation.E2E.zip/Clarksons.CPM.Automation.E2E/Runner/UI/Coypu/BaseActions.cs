﻿using Clarksons.CPM.Automation.E2E.Data.Fields;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Data;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using System;
using System.Collections.Generic;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public class BaseActions
    {
        protected BrowserSession driver;
        public BaseActions(BrowserSession browserSession)
        {
            this.driver = browserSession;
        }

        protected void AutoComplete(ElementScope autocomplete, string value)
        {
            Retry.Timeout(() => driver.AutoComplete(autocomplete, value), 20);
        }

        internal void WaitUntilLoaded()
        {
            var exceptions = new List<Exception>();
            try
            {
                // ToDo: WebPageCheckIdle implementation in Dev.Test.Image.Diff project
                //new WebPageCheckIdle().WaitForPageToBeIdle((IWebDriver)driver.Native, 2000);
                driver.TryUntil(
                    () => { },
                    () => driver.FindCss("div.cpm-loader").Missing(),
                    TimeSpan.FromSeconds(30));
                driver.TryUntil(
                    () => { },
                    () => IsMissing(() => driver.FindCss("i.fa-spinner")),
                    TimeSpan.FromSeconds(10));
            }
            catch (Exception ex)
            {
                exceptions.Add(ex);
            }
        }

        private bool IsMissing(Func<ElementScope> elementFinder)
        {
            try
            {
                return elementFinder().Missing();
            }
            catch
            {
                return true;
            }
        }

        protected IEnumerable<string> PopulateFields(
            ElementScope fieldsIn, bool useRandomData, int testDataSetNumber,
            Action preFills = null, IEnumerable<string> excludeInputs = null)
        {
            return fieldsIn.PopulateFields((label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData, testDataSetNumber, preFills, excludeInputs);
        }

        protected string InputField(
            ElementScope field, bool useRandomData,
            int fieldIndex, int testDataSetNumber)
        {
            return field.InputField((label, defaultType) => FieldData.GetFieldValidInputTypeOrDefault(label, defaultType),
                useRandomData, fieldIndex, testDataSetNumber);
        }
    }
}