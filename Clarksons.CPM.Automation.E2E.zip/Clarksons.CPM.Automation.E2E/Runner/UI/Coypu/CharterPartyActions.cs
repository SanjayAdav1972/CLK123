﻿using Clarksons.CPM.Automation.POM.Shared;
using Clarksons.CPM.Automation.Utilities;
using Clarksons.CPM.Automation.Utilities.Data;
using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using OpenQA.Selenium;
using Should.Fluent;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace Clarksons.CPM.Automation.E2E.Runner.UI.Coypu
{
    public class CharterPartyActions : BaseActions
    {
        public CharterParty charterParty { get; }
        public CharterPartyActions(BrowserSession browserSession) : base(browserSession)
        {
            this.charterParty = new CharterParty(browserSession);
        }

        public void AddNewCharterParty()
        {
            while (!charterParty.AddNewDocumentButton.Exists())
            {
                Thread.Sleep(250);              // Wait till ADD NEW button appears
            }
            
            charterParty.AddNewDocumentButton.ClickElement();
        }

        public void SelectCharterPartyStyle(string option)
        {
            charterParty.StyleSelection.SelectOption(option);
        }

        internal void WaitUntilExportsAreFinished()
        {
            var webdriver = (IWebDriver)driver.Native;
            while (webdriver.WindowHandles.Count > 1)
            {
                Thread.Sleep(250);
            }
        }

        public void CreateNew()
        {
            //Retry.Timeout(() =>
            //{
            //    charterParty.CreateButton.ClickElement();
            //    charterParty.CreateDialogTitle.IsDialogClosed();
            //}, 5);
            //WaitUntilLoaded();
            charterParty.CreateButton.ClickElement();
            Thread.Sleep(TimeSpan.FromSeconds(10));
        }

        public void SpecifyBroker(string broker)
        {
            while (!charterParty.BrokerAutocomplete.Exists())
            {
                Thread.Sleep(500);
            }
            AutoComplete(charterParty.BrokerAutocomplete, broker);
        }

        public void SpecifyCharterer(string charterer)
        {
            AutoComplete(charterParty.ChartererAutocomplete, charterer);
        }

        public void ViewEditor()
        {
            charterParty.ViewEditorButton.ClickElement();
            driver.HasContent("Compare against");
            WaitUntilLoaded();
        }

        public void ViewMainDetails()
        {
            charterParty.ViewMainDetailsButton.ClickElement();
        }

        public void SubjectsInputShouldNotBeEditable()
        {
            charterParty.SubjectsInput.CanChangeContent().Should().Be.False();
        }

        public void SubjectsAlertIconShouldNotBePresent()
        {
            charterParty.SubjectsAlertIcon.Disabled.Should().Be.True();
        }

        public void Save()
        {
            charterParty.Save.ClickElement();
            WaitUntilSavedSuccessfully();
        }

        public IEnumerable<string> GenerateAllInputTestDataForBlankFields()
        {
            var allInputs = charterParty.AllTextInputs.ToList();

            var testData = new List<string>();

            allInputs.ForEach(input =>
            {
                var testInputValue = input.Value;
                if (string.IsNullOrWhiteSpace(testInputValue))
                {
                    testInputValue = Guid.NewGuid().ToString().Substring(0, 5);
                    input.Enter(testInputValue);
                }
                testData.Add(testInputValue);
            });

            return testData;
        }

        public void CheckAllInputsContainSpecificValue(IEnumerable<string> inputData)
        {
            var testData = inputData.ToList();
            var allInputs = charterParty.AllTextInputs.ToList();
            if (allInputs.Count() != inputData.Count())
            {
                throw new Exception("Number of input fields did not match test data number");
            }
            for (int i = 0; i < allInputs.Count; i++)
            {
                var input = allInputs[i];
                var testValue = testData[i];
                if (input.Value != testValue)
                {
                    throw new Exception($"Input '{input.Name}({input.Id})' " +
                        $"value of {input.Value} did not match {testValue}");
                }
            }
        }

        public void SpecifyGoToLine(string lineNumber)
        {
            charterParty.GoToLine.Enter(lineNumber);
            charterParty.GoToLineNavigate.Click();
        }

        public void SpecifyOwnerGroup(string companyName)
        {
            AutoComplete(charterParty.OwnerGroup, companyName);
        }

        public void SpecifyCPDate(string date)
        {
            charterParty.CPDated.ClickElement();
            charterParty.CPDated.Enter(date);
        }

        public void SpecifyBPVoy4MBPShippingQuestionnaireCompletedDate(string date)
        {
            charterParty.BPVoy4MBPShippingQuestionnaireCompletedDate.Enter(date);
        }

        public void SpecifyBPVoy4MBPShippingQuestionnaireConfirmedDate(string date)
        {
            charterParty.BPVoy4MBPShippingQuestionnaireConfirmedDate.Enter(date);
        }

        public void SpecifyImoNUmber(string number)
        {
            charterParty.ImoNumber.Enter(number);
        }

        public void WaitUntilSavedSuccessfully()
        {
            driver.HasContent("saved successfully",
                new Options() { Timeout = TimeSpan.FromSeconds(10) })
                .Should().Be.True();
        }

        public void Delete()
        {
            charterParty.ToolbarMenu.ClickElement();
            charterParty.DeleteButton.ClickElement();
            driver.HasContent("Delete CP");
            Retry.Timeout(() => charterParty.ConfirmDeleteButton.ClickElement(), 15);
        }

        public void Q88SearchShouldExist()
        {
            charterParty.Q88Search.Exists().Should().Be.True();
        }

        public void Q88SearchShouldNotExist()
        {
            charterParty.Q88Search.Exists().Should().Be.False();
        }

        public void ClickExportButton()
        {
            charterParty.ExportButton.ClickElement();
        }

        public void ExportFixtureCharterParty()
        {
            charterParty.ExportCharterPartyLink.ClickElement();
        }

        public IEnumerable<string> CreateVessel(bool isFreetext = false)
        {
            var vesselTabsIncludingNewVesselButton = charterParty.VesselTabs;
            var vesselTabs = vesselTabsIncludingNewVesselButton
                .Take(vesselTabsIncludingNewVesselButton.Count() - 1);
            var newVesselTab = vesselTabsIncludingNewVesselButton.Last();

            var vesselNumber = vesselTabs.Count();

            var vesselSection = GetVisibleVesselSection();

            if (CurrentVesselTabPopulated(vesselSection))
            {
                newVesselTab.ClickElement();
                vesselNumber++;
                vesselSection = GetVisibleVesselSection();
            }

            if (isFreetext == true)
            {
                return PopulateFields(vesselSection, true, vesselNumber,
                    () =>
                    {
                        if (charterParty.VesselFreetextOption.Exists())
                        {
                            charterParty.VesselFreetextOption.CheckCheckbox();
                        }
                    });
            }
            else
            {
                return PopulateFields(vesselSection, true, vesselNumber,
                    () =>
                    {
                        if (charterParty.VesselFreetextOption.Exists(new Options() { Timeout = TimeSpan.FromMilliseconds(50) }))
                        {
                            charterParty.VesselFreetextOption.UncheckCheckbox();
                        }
                        //charterParty.Q88SearchInput.Enter("field not saved");
                    }, excludedVesselInputs);
            }
        }

        private IEnumerable<string> excludedVesselInputs => new string[] {
            "Search Q88...", "VesselDescriptionFreetextSelected" };

        private SnapshotElementScope GetVisibleVesselSection()
        {
            return driver.FindAllCss("[name='tabContainerForGroup2']")
                            .SingleOrDefault(x => !x.HasClass("ng-hide"));
        }

        private bool CurrentVesselTabPopulated(ElementScope vesselSection)
        {
            Func<ElementScope> getElement = null;
            if (charterParty.VesselFreetextOption.Exists(new Options() { Timeout = TimeSpan.FromMilliseconds(50) }) &&
                charterParty.VesselFreetextOption.IsCheckboxChecked())
            {
                getElement = () => vesselSection.GetInputByLabel("D. Vessel Description Freetext");
            }
            else
            {
                getElement = () => vesselSection.GetInputByLabel("Vessel Name");
            }
            return !string.IsNullOrWhiteSpace(getElement().GetInputDisplayText());
        }

        public void CheckVessel(int vesselNumber, IEnumerable<string> vesselData)
        {
            ChooseVesselOption(vesselNumber);
            var vesselSection = GetVisibleVesselSection();
            vesselSection.CheckFields(vesselData, excludedVesselInputs);
        }

        public void RemoveVessel(int vesselNumber)
        {
            var vesselRemoveButton = charterParty.VesselRemoveButtons.ToList()[vesselNumber];
            vesselRemoveButton.ClickElement();
        }

        public void ViewRecap()
        {
            charterParty.RecapSection.ClickElement();
        }

        public void ChooseVesselOption(int optionNumber)
        {
            charterParty.VesselTabs.ToList()[optionNumber].ClickElement();
        }

        public void ExportFixtureRecap()
        {
            charterParty.ExportRecapLink.ClickElement();
        }

        public void ResumeEditing()
        {
            WaitUntilLoaded();
            charterParty.ResumeEditingButton.ClickElement();
            WaitUntilLoaded();
        }
    }
}