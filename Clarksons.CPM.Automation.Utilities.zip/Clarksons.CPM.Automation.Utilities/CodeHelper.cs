﻿using System;

namespace Clarksons.CPM.Automation.Utilities
{
    public static class CodeHelper
    {
        public static void CanFail(Action action)
        {
            try
            {
                action();
            }
            catch
            {
                // Todo: Create custom Exception class to inform the action do not perform
            }
        }
    }
}
