﻿using OpenQA.Selenium;
using OpenQA.Selenium.Internal;
using OpenQA.Selenium.Support.UI;
using System;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    /// <summary>
    /// HTML Extension method for control fields
    /// </summary>
    public static class WebElementExtensions
    {
        public static void WaitForElementToExist(this IWebDriver driver, By by, TimeSpan timeout)
        {
            new WebDriverWait(driver, timeout).Until(ExpectedConditions.ElementExists(by));
        }

        public static IWebDriver ElementDriver(this IWebElement element)
        {
            return ((IWrapsDriver)element).WrappedDriver;
        }

        public static IWebElement Parent(this IWebElement element)
        {
            var javascriptExecutor = (IJavaScriptExecutor)element.ElementDriver();
            return (IWebElement)javascriptExecutor.ExecuteScript(
                "return arguments[0].parentNode;", element);
        }

        public static string FindIdOrNameOrElement(this IWebElement element, bool root = true)
        {
            if (element == null)
            {
                if (root == true)
                {
                    return "(no name of id set for element of any parent element)";
                }
                return null;
            }
            return (element.GetAttribute("name") ?? element.GetAttribute("id"))
                ?? FindIdOrNameOrElement(Parent(element), root: false);
        }
    }
}