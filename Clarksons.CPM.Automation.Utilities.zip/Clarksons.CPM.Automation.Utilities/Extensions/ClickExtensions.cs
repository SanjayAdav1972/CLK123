﻿using Coypu;
using OpenQA.Selenium;
using System;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    /// <summary>
    /// HTML Extension methods related to controls click element
    /// </summary>
    public static class ClickExtensions
    {
        public static void ClickElement(this ElementScope element)
        {
            element.Native().ClickElement();
        }

        public static void ClickElement(this IWebElement element)
        {
            element.MoveTo();
            element.ClickFallback();
        }

        internal static void MoveTo(this IWebElement element)
        {
            element.Execute("arguments[0].scrollIntoView(true); window.scrollBy(0,-400);");
        }

        private static void ClickFallback(this IWebElement element)
        {
            try
            {
                element.Click();
            }
            catch (Exception exception)
            {
                try
                {
                    var sva = exception;
                    element.Execute("arguments[0].click();");
                }
                catch (Exception exception2)
                {
                    var sva = exception2;
                    throw;
                }
            }
        }

        private static void Execute(this IWebElement element, string javascript)
        {
            var executor = (IJavaScriptExecutor)element.ElementDriver();
            executor.ExecuteScript(javascript, element);
        }
    }
}