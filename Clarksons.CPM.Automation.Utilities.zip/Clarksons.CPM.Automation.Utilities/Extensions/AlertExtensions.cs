﻿using OpenQA.Selenium;
using System;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    /// <summary>
    /// HTML Extension methods to work with Alerts (Accept and Dismiss Alert)
    /// </summary>
    public static class AlertExtensions
    {
        private static void WithAlert(this IWebDriver webDriver, Action<IAlert> perform, bool mustExist = true)
        {
            try
            {
                perform(webDriver.SwitchTo().Alert());
            }
            catch
            {
                if (mustExist)
                {
                    throw;
                }
            }
        }

        public static void AlertAccept(this IWebDriver webDriver)
        {
            webDriver.WithAlert(alert => alert.Accept());
        }

        public static void AlertCancel(this IWebDriver webDriver)
        {
            webDriver.WithAlert(alert => alert.Dismiss());
        }

        public static void AlertIgnore(this IWebDriver webDriver)
        {
            webDriver.WithAlert(alert => alert.Accept(), mustExist: false);
        }
    }
}
