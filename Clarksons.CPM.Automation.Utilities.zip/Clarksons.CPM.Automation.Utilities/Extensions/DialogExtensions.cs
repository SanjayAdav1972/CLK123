﻿using Coypu;
using System;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    /// <summary>
    /// HTML Extension method to to handly pop-up Dialog box
    /// </summary>
    public static class DialogExtensions
    {
        public static void IsDialogClosed(this ElementScope dialogTitle)
        {
            if (!dialogTitle.Missing())
            {
                throw new Exception("Dialog was not closed");
            }
        }
    }
}