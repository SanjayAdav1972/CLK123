﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Extensions
{
    /// <summary>
    /// HTML Extension method to find any control existence
    /// </summary>
    public static class EnumerableExtensions
    {
        public static T WithAny<T>(this IEnumerable<T> enumerable)
        {
            if (enumerable == null)
            {
                throw new ArgumentNullException(nameof(enumerable));
            }

            var r = new Random();
            var list = enumerable as IList<T> ?? enumerable.ToList();
            return list.Count == 0 ? default(T) : list[r.Next(0, list.Count)];
        }
    }
}