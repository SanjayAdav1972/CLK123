﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Clarksons.CPM.Automation.Utilities.Database
{
    /// <summary>
    /// Database related tasks
    /// </summary>
    public class DbInteraction
    {
        private readonly string _connectionstring;
        public DbInteraction()
        {
            if (ConfigurationManager.ConnectionStrings["RM"] != null)
            {
                _connectionstring = ConfigurationManager.ConnectionStrings["RM"].ConnectionString;
            }
        }

        public void ExecuteSelectQuery(string query)
        {
            using (var sqlConnection = new SqlConnection(_connectionstring))
            using (var cmd = new SqlCommand(query, sqlConnection))
            {
                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlConnection.Close();
            }
        }

        public SqlDataReader ExecuteSelectQueryAndReturnData(string query)
        {
            SqlDataReader reader = null;

            using (var sqlConnection = new SqlConnection(_connectionstring))
            using (var cmd = new SqlCommand())
            {
                
                cmd.CommandText = query;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = sqlConnection;
                sqlConnection.Open();
                reader = cmd.ExecuteReader();
                sqlConnection.Close();
            }

            return reader;
        }

        public void ExecuteUpdateQuery(string query)
        {
            using (var sqlConnection = new SqlConnection(_connectionstring))
            using (var cmd = new SqlCommand(query, sqlConnection))
            {
                sqlConnection.Open();
                cmd.ExecuteNonQuery();
                sqlConnection.Close();
            }
        }
    }
}
