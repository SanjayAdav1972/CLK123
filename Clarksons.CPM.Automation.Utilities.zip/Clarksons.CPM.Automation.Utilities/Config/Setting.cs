﻿using System;
using System.Configuration;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Config
{
    /// <summary>
    /// Methods to retrive the setting values from configuration files (e.g. App.config/App.CPM.INT.Config)
    /// </summary>
    public static class Setting
    {
        private static string Get(string setting)
        {
            return ConfigurationManager.AppSettings[setting];
        }

        private static string GetPath(string setting)
        {
            return Environment.ExpandEnvironmentVariables(Get(setting).ExpandBuildCommands());
        }

        private static string ExpandBuildCommands(this string path)
        {
            var dirParts = System.AppDomain.CurrentDomain.BaseDirectory.Split('\\');
            var solutionDir = string.Join("\\", dirParts.Take(dirParts.Length - 4));
            path = path.Replace("$(SolutionDir)", solutionDir);
            return path;
        }

        public static class Login
        {
            public static class NewBroker
            {
                public static string Username => Get("LoginNewBrokerUsername");
                public static string Password => Get("LoginNewBrokerPassword");
            }

            public static class Broker
            {
                public static string Username => Get("LoginBrokerUsername");
                public static string Password => Get("LoginBrokerPassword");
            }
        }

        public static class Company
        {
            public static string Broker => Get("SelectCompanyBroker");
            public static string Charterer => Get("SelectCompanyCharterer");
        }

        public static string ScreenshotStoreLocation => Get("ScreenshotStoreLocation");
        public static string ScreenshotArtifactLocation => Get("ScreenshotArtifactLocation");
        public static string HtmlReportStoreLocation => Get("HtmlReportStoreLocation");

        public static string Product => Get("Product");
        public static string Env => Get("Environment");
        public static string BaseUrl => Get("Url");
        public static string BrowserName => Get("AutomationUIBrowser");

        public static Device Device => (Config.Device)Enum.Parse(typeof(Config.Device),
            Get("AutomationUIResponsiveDevice"));
        public static Coypu.Drivers.Browser Browser => Coypu.Drivers.Browser.Parse(
            Get("AutomationUIBrowser"));
        public static TimeSpan ElementTimeout => TimeSpan.FromMilliseconds(int.Parse(
            Get("AutomationElementLocationTimeoutInMilliseconds")));
        public static bool ReuseBrowser => Boolean.Parse(
            Get("AutomationReuseBrowserSession"));
        public static bool UseFastDataEntry => Boolean.Parse(
            Get("AutomationUseFastInput"));

        public static string UserDownloadPath => GetPath("FileDownloadFolder");
        public static string UserPicturesPath => GetPath("ScreenshotPath");
        public static string UserDocumentPath => GetPath("DocumentFolder");

        public static bool UseSeleniumGrid2 => Boolean.Parse(Get("UseSeleniumGrid2"));
        public static string DockerComposeUpFile => GetPath("DockerComposeUpFile");
        public static string DockerComposeDownFile => GetPath("DockerComposeDownFile");

        public static string SeleniumGrid2Uri => Get("SeleniumGrid2Uri");
    }
}