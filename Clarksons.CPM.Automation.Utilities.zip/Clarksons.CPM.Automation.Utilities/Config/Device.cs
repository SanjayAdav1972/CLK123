﻿namespace Clarksons.CPM.Automation.Utilities.Config
{
    /// <summary>
    /// Enumeration type for the list of devices accessing the application
    /// </summary>
    public enum Device
    {
        DesktopMax,
        Mobile      // future implementation
    }
}