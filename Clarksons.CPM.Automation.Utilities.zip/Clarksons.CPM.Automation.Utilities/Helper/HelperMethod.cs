﻿using Clarksons.CPM.Automation.Utilities.Extensions;
using Coypu;
using NUnit.Framework;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Helper
{
    /// <summary>
    ///  Helper Methods
    /// </summary>
    public class HelperMethod
    {
        public static readonly List<string> SoftAssertlist = new List<string>();
        protected BrowserSession driver;
        public HelperMethod(BrowserSession browserSession)
        {
            this.driver = browserSession;
        }

        public void VerifyThatToastMessageSays(string expectedMessage)
        {
            WebElementExtensions.WaitForElementToExist((IWebDriver)driver.Native, By.CssSelector(".toast-message"), TimeSpan.FromSeconds(350));

            var toast = driver.FindCss(".toast-message");
            var toastMessage = driver.FindCss(".toast-message").Text.ToLower();
            dismissToastMessage(toast);
            if (toastMessage != null)
                Assert.IsTrue(toastMessage.Contains(expectedMessage.ToLower()),
                "\n>>> Toast message did not match expected message!\n"
                + ">>> Toast Message: " + toastMessage + "\n"
                + ">>> Expected Message: " + expectedMessage + "\n");
        }

        private void dismissToastMessage(ElementScope toast)
        {
            toast.Click();

            while (toast.Exists())
            {
                WaitForSeconds(1);
            }
        }

        private void WaitForSeconds(int secods)
        {
            System.Threading.Thread.Sleep(secods * 1000);
        }

        public void CreateSoftAssertion(string errormessage)
        {
            SoftAssertlist.Add(errormessage);
        }
        public void ValidateSoftAssertion()
        {
            if (SoftAssertlist.Count <= 0) return;

            int eCount = SoftAssertlist.Count;

            Console.WriteLine("\n=============Soft Assertion Error List Start=============\n");
            Console.WriteLine("Soft Assertion list contains {0} error{1}:\n", eCount, eCount > 1 ? "s" : "");
            foreach (var errorDescription in SoftAssertlist.Where(errorDescription => !String.IsNullOrEmpty(errorDescription)))
            {
                Console.WriteLine(errorDescription);
            }
            Console.WriteLine("=============Soft Assertion Error List End=============\n");

            SoftAssertlist.Clear();

            NUnit.Framework.Assert.Fail("Soft Assertion errors have been encountered during test execution. Please refer to the test output/report for more details.");
        }

        public string GetPageUrl()
        {
            return driver.Location.AbsoluteUri;
        }

        public string RemoveinvalidCharacters(string toString)
        {
            string invalid = new string(Path.GetInvalidFileNameChars()) + new string(Path.GetInvalidPathChars());
            return invalid.Aggregate(toString, (current, c) => current.Replace(c, '_'));
        }
        public IWebElement FindElement(By by)
        {
            return ((IWebDriver)driver.Native).FindElement(by);
        }

        public IList<IWebElement> FindElements(By by)
        {
            return ((IWebDriver)driver.Native).FindElements(by);
        }
    }
}