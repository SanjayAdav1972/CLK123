﻿using Clarksons.CPM.Automation.Utilities.Config;
using System.IO;
using System.Linq;

namespace Clarksons.CPM.Automation.Utilities.Helper
{
    /// <summary>
    /// HTML Extension methods for File Management
    /// </summary>
    public static class FileHelper
    {
        public static void DeleteFiles(string directoryName, string filePattern)
        {
            DirectoryInfo taskDirectory = new DirectoryInfo(directoryName);
            FileInfo[] taskFiles = taskDirectory.GetFiles(filePattern);

            foreach (var file in taskFiles)
            {
                file.Delete();
            } 
        }

        public static bool CheckFileExist(string filePattern, string containing = null)
        {
            string filePath = Setting.UserDownloadPath;
            DirectoryInfo taskDirectory = new DirectoryInfo(filePath);
            var taskFiles = taskDirectory.GetFiles(filePattern);
            if (containing != null)
            {
                taskFiles = taskFiles.Where(x => x.Name.Contains(containing)).ToArray();
            }

            return taskFiles.Any();
        }

        public static FileInfo GetFile(string directoryName, string filePattern, string containing)
        {
            DirectoryInfo taskDirectory = new DirectoryInfo(directoryName);
            return taskDirectory.GetFiles(filePattern)
                .OrderByDescending(x => x.CreationTimeUtc)
                .First(x => x.Name.Contains(containing));
        }
    }
}
